extends Node3D
const HAIR = [Color("39a49f"),Color("232e41"),Color("e8d7b7"),Color("944d50"),Color("b3a7c7")]
const COAT = [Color("586170"),Color("255f69"),Color("6d3846"),Color("a7a08a")]
const SKIN = [Color("e4b38f"),Color("c68a64"),Color("8c5a45"),Color("f0cbb1")]
var body_mesh
var material
var weapon_root
var weapon_mesh
var current_frame=0
var facing=1.0
var appearance={}
var clock=0.0
var walking=false
var sprinting=false
var locked_pose=false
var shadow
var visual_scale=1.0

func _ready():
	body_mesh=MeshInstance3D.new()
	var q=QuadMesh.new(); q.size=Vector2(2.45,2.45); q.subdivide_width=20; q.subdivide_depth=20
	body_mesh.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	body_mesh.mesh=q
	material=ShaderMaterial.new(); material.shader=load("res://shaders/hunter.gdshader")
	body_mesh.material_override=material
	body_mesh.position.y=1.17
	add_child(body_mesh)
	shadow=MeshInstance3D.new()
	var sm=CylinderMesh.new(); sm.top_radius=0.5; sm.bottom_radius=0.5; sm.height=0.008; sm.radial_segments=16
	shadow.mesh=sm
	var shade=StandardMaterial3D.new(); shade.albedo_color=Color(0.025,0.04,0.07,0.65); shade.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; shade.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	shadow.material_override=shade; shadow.position.y=0.035; shadow.scale.z=0.55
	add_child(shadow)
	weapon_root=Node3D.new(); add_child(weapon_root)
	if not appearance.is_empty(): apply_appearance(appearance)

func apply_appearance(d):
	appearance=d.duplicate(true)
	if material==null: return
	material.set_shader_parameter("atlas",load("res://assets/hunter_f.png" if d.gender==1 else "res://assets/hunter_m.png"))
	material.set_shader_parameter("hair_color",HAIR[int(d.hair_color)%HAIR.size()])
	material.set_shader_parameter("coat_color",COAT[int(d.coat)%COAT.size()])
	material.set_shader_parameter("skin_color",SKIN[int(d.skin)%SKIN.size()])
	material.set_shader_parameter("chest",float(d.chest-1) if d.gender==1 else 0.0)
	material.set_shader_parameter("hair_style",float(d.hair)-1.0)
	scale=Vector3([0.88,1.0,1.12][int(d.body)],[0.91,1.0,1.10][int(d.height)],1.0)*visual_scale
	build_weapon(int(d.weapon))
	set_pose(current_frame)

func build_weapon(kind):
	for child in weapon_root.get_children(): child.queue_free()
	var names=["sword","dao","katana","spear","fist","focus"]
	weapon_mesh=Sprite3D.new()
	weapon_mesh.texture=load("res://assets/"+names[kind]+".svg")
	weapon_mesh.pixel_size=0.011
	weapon_mesh.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	weapon_mesh.texture_filter=BaseMaterial3D.TEXTURE_FILTER_NEAREST
	weapon_mesh.no_depth_test=false
	weapon_root.add_child(weapon_mesh)

func set_pose(index):
	current_frame=index
	if material==null: return
	material.set_shader_parameter("frame",float(index))
	material.set_shader_parameter("flipped",1.0 if facing<0 else 0.0)
	var hand=[Vector2(.30,1.0),Vector2(.30,1.0),Vector2(.47,1.0),Vector2(.30,1.05),Vector2(.67,.75),Vector2(.67,.9),Vector2(.70,.9),Vector2(.65,1.15),Vector2(-.36,1.6),Vector2(.8,1.5),Vector2(.70,.8),Vector2(.55,1.25),Vector2(.15,1.3),Vector2(.3,.9),Vector2(.2,.5),Vector2(.7,1.5)]
	weapon_root.position=Vector3(hand[index].x*facing,hand[index].y,0.12)
	weapon_mesh.flip_h=facing<0
	weapon_mesh.rotation.z=([-1.1,-1.1,-.8,-1.2,-1.6,-1.5,-1.5,-.8,0.8,-1.7,-2.5,-.6,.3,1.1,0.0,-1.2][index])*facing

func _process(delta):
	clock+=delta
	if not locked_pose:
		if walking: set_pose((5 if int(clock*10)%2==0 else 6) if sprinting else (2 if int(clock*7)%2==0 else 3))
		else: set_pose(0 if int(clock*1.6)%2==0 else 1)

func hit_flash():
	material.set_shader_parameter("flash",0.9)
	var t=create_tween()
	t.tween_method(func(v): material.set_shader_parameter("flash",v),0.9,0.0,0.22)
