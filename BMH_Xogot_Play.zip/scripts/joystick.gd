extends Control
signal direction_changed(direction)
var direction=Vector2.ZERO
var active=false
var touch_id=-1
func _ready():
	mouse_filter=Control.MOUSE_FILTER_STOP
func _draw():
	var center=size*.5
	draw_circle(center,58,Color(.05,.13,.18,.52))
	draw_arc(center,58,0,TAU,48,Color(.56,.76,.76,.5),2,true)
	for d in [Vector2.UP,Vector2.DOWN,Vector2.LEFT,Vector2.RIGHT]: draw_line(center+d*43,center+d*51,Color(.8,.87,.83,.7),2)
	draw_circle(center+direction*34,24,Color(.32,.54,.57,.7))
	draw_arc(center+direction*34,24,0,TAU,32,Color(.78,.9,.85,.8),2,true)
func _gui_input(event):
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
		active=event.pressed
		if active: update_direction(event.position)
		else: release()
		accept_event()
	elif event is InputEventMouseMotion and active:
		update_direction(event.position); accept_event()
func update_direction(p):
	direction=((p-size*.5)/44).limit_length()
	if direction.length()<.14: direction=Vector2.ZERO
	direction_changed.emit(direction); queue_redraw()
func _input(event):
	if event is InputEventScreenTouch:
		if event.pressed and get_global_rect().has_point(event.position) and touch_id<0:
			touch_id=event.index; update_direction(event.position-global_position)
		elif not event.pressed and event.index==touch_id: touch_id=-1; release()
	elif event is InputEventScreenDrag and event.index==touch_id: update_direction(event.position-global_position)
	elif event is InputEventMouseButton and not event.pressed and active: release()
func release():
	active=false; direction=Vector2.ZERO; direction_changed.emit(direction); queue_redraw()
