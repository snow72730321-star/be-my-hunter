extends Node3D
const Actor=preload("res://scripts/hunter_actor.gd")
signal near_changed(id,caption)
signal moved(distance)
var hero
var player
var camera
var environment
var virtual_input=Vector2.ZERO
var can_move=false
var battle_mode=false
var camera_anchor=Vector3.ZERO
var near_id=""
var time=0.0
var dash_left=0.0
var shake_left=0.0
var shake_strength=0.0
var points={}
var npc_actors={}
var city
var arena
var monster
var gate_ring
var beacons=[]
var labels=[]
var font
var state
var afterimage_left=0.0
var motion_profiles={}
var ruined=false
var original_materials={}

func _ready():
	motion_profiles=JSON.parse_string(FileAccess.get_file_as_string("res://data/motion_profiles.json"))
	font=preload("res://scripts/fonts.gd").korean()
	var env=WorldEnvironment.new()
	environment=Environment.new(); environment.background_mode=Environment.BG_COLOR; environment.background_color=Color("132b41")
	environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; environment.ambient_light_color=Color("a6acb8"); environment.ambient_light_energy=0.55
	environment.tonemap_mode=Environment.TONE_MAPPER_FILMIC
	env.environment=environment; add_child(env)
	var sun=DirectionalLight3D.new(); sun.rotation_degrees=Vector3(-53,-28,0); sun.light_color=Color("e5d3bd"); sun.light_energy=0.95; sun.shadow_enabled=true; add_child(sun)
	city=Node3D.new(); add_child(city)
	build_city()
	player=CharacterBody3D.new(); player.position=Vector3(0,0.08,6); add_child(player)
	var cs=CollisionShape3D.new(); var shape=CapsuleShape3D.new(); shape.radius=.30; shape.height=1.0; cs.shape=shape; cs.position.y=.5; player.add_child(cs)
	hero=Actor.new(); player.add_child(hero)
	hero.visual_scale=1.45
	camera=Camera3D.new(); camera.projection=Camera3D.PROJECTION_ORTHOGONAL; camera.size=17; camera.far=250; camera.current=true; add_child(camera)
	camera_anchor=player.position
	camera.position=camera_anchor+Vector3(0,19,16); camera.look_at(camera_anchor)
	arena=Node3D.new(); arena.position=Vector3(130,0,0); add_child(arena)
	build_arena()

func material(color,emission=0.0):
	var m=StandardMaterial3D.new(); m.albedo_color=Color(color)
	m.roughness=0.82
	if emission>0:
		m.emission_enabled=true; m.emission=Color(color); m.emission_energy_multiplier=emission
	return m

func box(parent,pos,size,color,solid=false,glow=0.0):
	var mesh=MeshInstance3D.new(); var shape=BoxMesh.new(); shape.size=size
	mesh.mesh=shape; mesh.material_override=material(color,glow); mesh.position=pos; parent.add_child(mesh)
	if solid:
		var body=StaticBody3D.new(); var collider=CollisionShape3D.new(); var bs=BoxShape3D.new(); bs.size=size
		collider.shape=bs; body.position=pos; body.add_child(collider); parent.add_child(body)
	return mesh

func text3(parent,message,pos,sz=42,color=Color("f1dba7")):
	var l=Label3D.new(); l.text=message; l.font=font; l.font_size=sz; l.pixel_size=.012; l.position=pos
	l.modulate=color; l.no_depth_test=true; l.outline_size=5; l.outline_modulate=Color("102032"); l.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	parent.add_child(l); labels.append(l); return l

func building(pos,size,color,title):
	box(city,pos+Vector3(0,size.y/2,0),size,color,true)
	box(city,pos+Vector3(0,size.y+.14,0),Vector3(size.x+.38,.28,size.z+.38),"334659")
	box(city,pos+Vector3(0,.22,size.z/2+.5),Vector3(size.x+.7,.4,1.2),"607782",true)
	box(city,pos+Vector3(0,2.3,size.z/2+.12),Vector3(size.x*.7,.65,.2),"102a3b")
	text3(city,title,pos+Vector3(0,2.36,size.z/2+.28),32)
	box(city,pos+Vector3(0,.9,size.z/2+.04),Vector3(1.0,1.7,.13),"15303c")
	box(city,pos+Vector3(.25,1.1,size.z/2+.12),Vector3(.06,.23,.07),"ddb36c",false,.3)
	for x in [-1,1]:
		box(city,pos+Vector3(x*size.x*.31,1.22,size.z/2+.12),Vector3(1.3,1.45,.16),"d5b671",false,.55)
		box(city,pos+Vector3(x*size.x*.31,1.22,size.z/2+.24),Vector3(.055,1.48,.1),"233e4d")
		for y in range(1,int(size.y/2.0)):
			box(city,pos+Vector3(x*size.x*.3,y*1.7+1.25,size.z/2+.07),Vector3(.9,.85,.1),"86acb1",false,.25)
	box(city,pos+Vector3(size.x*.25,size.y+.5,-.6),Vector3(1.2,.8,1.5),"49606d")
	for i in range(4):
		box(city,pos+Vector3(size.x*.25,size.y+.7,-1.1+i*.27),Vector3(1.22,.035,.04),"9aa7a3")

func tree(pos,scale_value=1.0):
	box(city,pos+Vector3(0,.72*scale_value,0),Vector3(.35,1.5*scale_value,.35),"514b49",true)
	var mesh=MeshInstance3D.new(); var s=SphereMesh.new(); s.radius=1.25*scale_value; s.height=2.25*scale_value; s.radial_segments=7; s.rings=4
	mesh.mesh=s; mesh.material_override=material("356465"); mesh.position=pos+Vector3(0,2.4*scale_value,0); city.add_child(mesh)
	box(city,pos+Vector3(0,.06,0),Vector3(2.2,.12,2.2),"51706d")

func lamp(pos):
	box(city,pos+Vector3(0,1.55,0),Vector3(.13,3.1,.13),"263b4c",true)
	box(city,pos+Vector3(.35,3.1,0),Vector3(.9,.14,.28),"edcb89",false,.8)
	var light=OmniLight3D.new(); light.position=pos+Vector3(.3,2.75,0); light.light_color=Color("f9c989"); light.light_energy=.65; light.omni_range=5; city.add_child(light)

func add_point(id,caption,pos,npc=false,preset=0):
	points[id]={"position":pos,"caption":caption,"active":true}
	var ring=MeshInstance3D.new(); var tor=TorusMesh.new(); tor.inner_radius=.43; tor.outer_radius=.5; tor.rings=24; tor.ring_segments=6
	ring.mesh=tor; ring.material_override=material("6de5cc",.6); ring.position=pos+Vector3(0,.05,0); city.add_child(ring); points[id].ring=ring
	var label=text3(city,caption,pos+Vector3(0,2.65,0),28,Color("c5eadf")); points[id].label=label
	if npc:
		var a=Actor.new(); city.add_child(a); a.position=pos
		var d={"gender":preset%2,"body":1,"height":0,"chest":1,"hair":0,"hair_color":(preset+1)%5,"coat":(preset+1)%4,"skin":0,"weapon":4}
		a.visual_scale=1.25; a.apply_appearance(d); a.weapon_root.visible=false; npc_actors[id]=a

func build_city():
	box(city,Vector3(0,-.3,0),Vector3(90,.5,92),"445b65",true)
	# Continuous streets and independently collidable sidewalks/buildings.
	box(city,Vector3(0,.012,4),Vector3(83,.04,8),"273e4d")
	box(city,Vector3(0,.015,0),Vector3(7,.04,82),"2a4251")
	box(city,Vector3(17,.016,-20),Vector3(29,.04,7),"273e4d")
	box(city,Vector3(0,.02,30),Vector3(74,.04,7),"2d4755")
	for x in range(-38,40,4):
		box(city,Vector3(x,.04,4),Vector3(1.7,.018,.1),"bba875")
	for z in range(-37,40,4):
		box(city,Vector3(0,.04,z),Vector3(.1,.018,1.7),"c4b88c")
	for i in range(6):
		box(city,Vector3(-3+i*1.1,.055,-2),Vector3(.5,.02,2),"a1b9b6")
		box(city,Vector3(-3+i*1.1,.055,10),Vector3(.5,.02,2),"a1b9b6")
	# Pavement seams, road studs and wet reflection patches.
	for x in range(-40,42,3):
		for z in [-.5,8.5,25.5,34.5]:
			box(city,Vector3(x,.03,z),Vector3(.03,.03,1.5),"658087")
	for i in range(25):
		var x=sin(i*39.7)*36; var z=cos(i*7.4)*3+4
		box(city,Vector3(x,.052,z),Vector3(.5+abs(sin(i*8.))*2,.01,.16),"426679")
	building(Vector3(-10,0,-8),Vector3(9,4.2,6),"5e6d70","백도식 수리점")
	building(Vector3(11,0,-12),Vector3(12,7.3,10),"677f8b","세계헌터협회 · 서림")
	building(Vector3(-23,0,10),Vector3(7,4.5,7),"586e73","오혜진 약국")
	building(Vector3(-29,0,-13),Vector3(9,8.5,11),"5b6574","교류 공방")
	building(Vector3(28,0,-10),Vector3(9,5.0,8),"526571","차원교류 안내소")
	building(Vector3(16,0,22),Vector3(10,6.0,8),"63727b","서림 기록원")
	building(Vector3(-29,0,25),Vector3(8,9,8),"576879","서림 주거동")
	for i in range(7):
		var x=-35+i*11
		building(Vector3(x,0,-39),Vector3(7,8+(i%3)*4,5),"405469","")
	# Northern gate plaza, southern persistent refuge, eastern waterside park.
	box(city,Vector3(23,.06,-28),Vector3(18,.12,12),"3c525e")
	box(city,Vector3(-11,.045,37),Vector3(23,.09,10),"6e7d7d")
	for i in range(3):
		box(city,Vector3(-19+i*7,1.1,39),Vector3(5,2.2,4),"8d9b90",true)
		box(city,Vector3(-19+i*7,2.25,39),Vector3(5.3,.25,4.3),"d9c79f")
	text3(city,"남쪽 대피 거점",Vector3(-11,3.4,37),36)
	box(city,Vector3(36,.03,17),Vector3(12,.09,22),"395e62")
	box(city,Vector3(43,.02,9),Vector3(3,.09,66),"315f74")
	for z in range(-20,39,3):
		box(city,Vector3(41.3,.7,z),Vector3(.12,1.4,.12),"8a9f9c",true)
		box(city,Vector3(41.3,1.35,z),Vector3(.12,.12,3.2),"bbc6b4")
	for pos in [Vector3(-18,0,-2),Vector3(-19,0,19),Vector3(23,0,13),Vector3(31,0,17),Vector3(37,0,25),Vector3(8,0,17),Vector3(-8,0,23),Vector3(-31,0,3),Vector3(7,0,-27),Vector3(35,0,-26)]:
		tree(pos,1.0)
	for pos in [Vector3(-15,0,9),Vector3(6,0,9),Vector3(19,0,-17),Vector3(-5,0,28),Vector3(32,0,7)]: lamp(pos)
	# Repair props, benches, air-conditioners, planters, shelter bus.
	for i in range(4):
		box(city,Vector3(-14+i*.75,.35,-4),Vector3(.6,.7,.7),"a88864",true)
	for pos in [Vector3(29,0,13),Vector3(-6,0,15),Vector3(32,0,25)]:
		box(city,pos+Vector3(0,.6,0),Vector3(2,.18,.7),"af9670",true)
		box(city,pos+Vector3(0,1.0,-.3),Vector3(2,.6,.1),"8a785e")
	box(city,Vector3(-5,1.0,22),Vector3(2.7,2.0,6.5),"608e88",true)
	box(city,Vector3(-5,1.65,24.8),Vector3(2.2,.7,.15),"adc6c5")
	for z in [20,23.7]:
		box(city,Vector3(-6.38,.42,z),Vector3(.3,.65,.7),"172634")
		box(city,Vector3(-3.62,.42,z),Vector3(.3,.65,.7),"172634")
	add_point("baek","백도식 · 수리점",Vector3(-9,0,-3),true,0)
	add_point("jian","이지안 · 협회 등록",Vector3(9,0,-5),true,1)
	add_point("hyejin","오혜진 · 약품",Vector3(-23,0,15),true,3)
	add_point("taeo","박태오 · 구조 지원",Vector3(26,0,10),true,0)
	add_point("manifest","대피 명단 · 버스",Vector3(-2,0,19))
	add_point("refuge","휴식 · 대피 거점",Vector3(-10,0,34))
	add_point("gate","침략형 게이트",Vector3(21,0,-27))
	gate_ring=Node3D.new(); gate_ring.position=Vector3(21,2.5,-28); city.add_child(gate_ring)
	for i in range(32):
		var a=i*TAU/32.0
		var piece=box(gate_ring,Vector3(sin(a)*1.7,cos(a)*2.6,0),Vector3(.20,.35,.26),"65edcf",false,1)
		piece.rotation.z=-a
		beacons.append(piece)
	box(gate_ring,Vector3(0,0,.09),Vector3(2.8,4.4,.10),"183346")
	for p in [Vector3(-44,2,0),Vector3(44,2,0)]: box(city,p,Vector3(1,4,90),"283e4e",true)
	for p in [Vector3(0,2,-43),Vector3(0,2,45)]: box(city,p,Vector3(90,4,1),"283e4e",true)

func build_arena():
	box(arena,Vector3(0,-.1,0),Vector3(32,.2,18),"253d4d",true)
	for x in range(-15,16,2): box(arena,Vector3(x,.02,0),Vector3(.025,.02,15),"45616b")
	for z in range(-7,8,2): box(arena,Vector3(0,.022,z),Vector3(31,.02,.025),"45616b")
	for i in range(9):
		box(arena,Vector3(-15+i*4,2.0,-6),Vector3(1.2,4,1.2),"446370")
		box(arena,Vector3(-15+i*4,3.2,-5.3),Vector3(.4,.35,.1),"56b9b0",false,.6)
	text3(arena,"경계를 지키는 일",Vector3(0,4,-6),38)
	monster=Node3D.new(); monster.position=Vector3(5,0,0); arena.add_child(monster)
	box(monster,Vector3(0,1.3,0),Vector3(1.6,1.8,1.1),"354452")
	box(monster,Vector3(0,2.0,.35),Vector3(1.3,.7,.9),"546272")
	for x in [-1,1]:
		box(monster,Vector3(x*.7,.35,.1),Vector3(.55,.7,.7),"233546")
		var arm=box(monster,Vector3(x*1.0,1.1,.2),Vector3(.5,1.4,.65),"3b4f5c"); arm.rotation.z=x*.32
		var horn=box(monster,Vector3(x*.58,2.6,.1),Vector3(.18,.85,.3),"73d8c5",false,.4); horn.rotation.z=x*-.3
		box(monster,Vector3(x*.35,2.05,.84),Vector3(.25,.13,.06),"f8b887",false,.8)
	box(monster,Vector3(0,1.45,.59),Vector3(.40,.60,.08),"68ebcb",false,.8)
	arena.visible=false

func set_appearance(d):
	hero.apply_appearance(d)

func apply_state(model):
	state=model
	if state==null or state.s.is_empty(): return
	var s=state.s
	if ruined!=bool(s.world.collapsed):
		ruined=bool(s.world.collapsed)
		for child in city.get_children():
			if child is MeshInstance3D and child.position.z<28 and child.material_override is StandardMaterial3D:
				if ruined:
					original_materials[child.get_instance_id()]=child.material_override
					child.material_override=material("24323e")
				elif original_materials.has(child.get_instance_id()):
					child.material_override=original_materials[child.get_instance_id()]
	for id in points:
		points[id].active=true
	if s.npc.baek.life=="DEAD":
		npc_actors.baek.visible=false; points.baek.active=false
	else:
		var pos=Vector3(-17,0,34) if s.npc.baek.location=="REFUGE" else Vector3(-9,0,-3)
		npc_actors.baek.position=pos; npc_actors.baek.visible=true
		points.baek.position=pos; points.baek.ring.position=pos+Vector3(0,.05,0); points.baek.label.position=pos+Vector3(0,2.65,0)
	points.gate.active=not s.world.gate_cleared and not s.world.collapsed
	gate_ring.visible=points.gate.active
	if s.world.collapsed:
		for id in ["jian","hyejin","taeo","manifest"]:
			var ix=["jian","hyejin","taeo","manifest"].find(id)
			var pos=Vector3(-7+ix*3.5,0,35)
			points[id].position=pos; points[id].ring.position=pos+Vector3(0,.05,0); points[id].label.position=pos+Vector3(0,2.65,0)
			if npc_actors.has(id): npc_actors[id].position=pos
		if player.position.z<28: player.position=Vector3(0,.08,32)
	else:
		var origins={"jian":Vector3(9,0,-5),"hyejin":Vector3(-23,0,15),"taeo":Vector3(26,0,10),"manifest":Vector3(-2,0,19)}
		for id in origins:
			points[id].position=origins[id]; points[id].ring.position=origins[id]+Vector3(0,.05,0); points[id].label.position=origins[id]+Vector3(0,2.65,0)
			if npc_actors.has(id): npc_actors[id].position=origins[id]
	for id in points:
		points[id].ring.visible=points[id].active; points[id].label.visible=points[id].active

func dash():
	if can_move and dash_left<=0: dash_left=.25

func _physics_process(delta):
	if player==null: return
	var direction=virtual_input
	if can_move:
		direction+=Vector2(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A)),float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W)))
		direction+=Vector2(float(Input.is_physical_key_pressed(KEY_RIGHT))-float(Input.is_physical_key_pressed(KEY_LEFT)),float(Input.is_physical_key_pressed(KEY_DOWN))-float(Input.is_physical_key_pressed(KEY_UP)))
	else: direction=Vector2.ZERO
	direction=direction.limit_length()
	dash_left=maxf(0,dash_left-delta)
	var speed=10.5 if dash_left>0 else 4.6
	player.velocity=Vector3(direction.x*speed,-2,direction.y*speed)
	if state!=null and not state.s.is_empty() and state.s.world.collapsed and player.position.z<28: player.position.z=28
	if can_move:
		var previous=player.position
		player.move_and_slide()
		var distance=Vector2(player.position.x-previous.x,player.position.z-previous.z).length()
		if distance>0: moved.emit(distance)
	hero.walking=direction.length()>.1
	hero.sprinting=dash_left>0
	if abs(direction.x)>.1: hero.facing=sign(direction.x)
	if can_move:
		var closest=""
		var best=3.4
		for id in points:
			if not points[id].active: continue
			var d=player.position.distance_to(points[id].position)
			if d<best: best=d; closest=id
		if closest!=near_id:
			near_id=closest
			near_changed.emit(closest,points[closest].caption if not closest.is_empty() else "가까이 다가가세요")

func _process(delta):
	time+=delta
	if camera==null: return
	if not battle_mode:
		camera_anchor=camera_anchor.lerp(player.position,1.0-exp(-delta*7))
		camera.position=camera_anchor+Vector3(0,19,16)
		camera.look_at(camera_anchor+Vector3(0,.2,0))
	else:
		camera.position=Vector3(130,5.8,18)
		camera.look_at(Vector3(130,1,0))
	if shake_left>0:
		shake_left-=delta
		camera.h_offset=sin(time*93)*shake_strength
		camera.v_offset=cos(time*117)*shake_strength*.5
	else:
		camera.h_offset=0; camera.v_offset=0
	if gate_ring!=null: gate_ring.rotation.z=sin(time*.6)*.025
	for i in range(beacons.size()): beacons[i].scale=Vector3.ONE*(.85+sin(time*2+i*.5)*.15)
	if monster!=null and battle_mode: monster.position.y=sin(time*2.3)*.05

func enter_battle():
	battle_mode=true; can_move=false; virtual_input=Vector2.ZERO
	city.visible=false; arena.visible=true
	player.position=Vector3(125,0.08,0)
	hero.facing=1; hero.locked_pose=true; hero.set_pose(0)
	camera.size=14
	monster.visible=true; monster.scale=Vector3.ONE

func exit_battle(pos):
	battle_mode=false; arena.visible=false; city.visible=true
	player.position=pos; hero.locked_pose=false; camera.size=17
	camera_anchor=pos

func shake(power,duration):
	shake_strength=power; shake_left=duration

func burst(pos,color,motion="slash"):
	var root=Node3D.new(); add_child(root); root.position=pos
	var rng=RandomNumberGenerator.new(); rng.seed=4182 # Visual-only RNG, never touches campaign streams.
	for i in range(14):
		var streak=box(root,Vector3.ZERO,Vector3(.06,.06,.06),color,false,.9)
		var vec=Vector3(rng.randf_range(-1.8,1.8),rng.randf_range(-1.0,1.4),rng.randf_range(-.1,.2))
		var t=create_tween().set_parallel(true)
		t.tween_property(streak,"position",vec,.34)
		t.tween_property(streak,"scale",Vector3.ZERO,.34)
	var arc=MeshInstance3D.new(); var mesh=TorusMesh.new(); mesh.inner_radius=.72; mesh.outer_radius=.79; mesh.rings=32; mesh.ring_segments=6
	arc.mesh=mesh; arc.material_override=material(color,.8); arc.rotation_degrees=Vector3(77,0,-35 if motion!="thrust" else 0)
	root.add_child(arc)
	if motion!="cast":
		arc.visible=false
		slash_ribbon(root,color,motion)
	var tween=create_tween(); tween.tween_property(arc,"scale",Vector3(1.8,1.8,1.8),.18); tween.tween_property(arc,"scale",Vector3.ZERO,.10)
	tween.tween_callback(root.queue_free)

func strike_enemy(motion,color):
	var family=["SWORD","DAO","KATANA","SPEAR","FIST","FOCUS"][int(hero.appearance.weapon)]
	var profile=motion_profiles[family]
	if motion!="cast": motion=profile.vfx
	hero.locked_pose=true; hero.set_pose(8 if motion!="cast" else 15)
	var start=player.position
	var close=Vector3(133.0,.08,0)
	var tween=create_tween()
	if motion=="cast":
		tween.tween_interval(.17)
	else:
		tween.tween_property(player,"position",close,float(profile.approach)).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
	await tween.finished
	if family=="KATANA": make_afterimage(start.lerp(close,.3)); make_afterimage(start.lerp(close,.6))
	hero.set_pose(int(profile.impact_frame) if motion!="cast" else 15)
	burst(Vector3(135,1.3,.8),color,motion)
	var impact=create_tween(); impact.tween_property(monster,"position:x",5.45,.07); impact.tween_property(monster,"position:x",5.0,.15)
	await get_tree().create_timer(.13).timeout
	hero.set_pose(int(profile.follow_frame) if motion!="cast" else 11)
	await get_tree().create_timer(.13).timeout
	var retreat=create_tween(); retreat.tween_property(player,"position",start,.18).set_trans(Tween.TRANS_QUAD)
	await retreat.finished
	hero.set_pose(0)

func strike_player():
	hero.set_pose(13); hero.hit_flash()
	burst(player.position+Vector3(0,1.25,.6),"f48378","heavy")
	var p=player.position
	var t=create_tween(); t.tween_property(player,"position:x",p.x-.45,.08); t.tween_property(player,"position",p,.20)
	await t.finished
	hero.set_pose(0)

func slash_ribbon(parent,color,motion):
	var geometry=ImmediateMesh.new()
	geometry.surface_begin(Mesh.PRIMITIVE_TRIANGLES)
	var radius=1.6 if motion=="heavy" else 1.15
	for i in range(12):
		var a=-1.6+i*.19
		var b=a+.19
		var outer_a=Vector3(cos(a)*radius,sin(a)*radius,.25)
		var outer_b=Vector3(cos(b)*radius,sin(b)*radius,.25)
		var inner_a=outer_a*.74
		var inner_b=outer_b*.74
		for v in [outer_a,outer_b,inner_a,inner_a,outer_b,inner_b]:
			geometry.surface_add_vertex(v)
	geometry.surface_end()
	var mesh=MeshInstance3D.new(); mesh.mesh=geometry
	mesh.material_override=material(color,1.0); mesh.material_override.cull_mode=BaseMaterial3D.CULL_DISABLED
	mesh.rotation.z=-.65
	if motion=="thrust": mesh.scale=Vector3(2.2,.15,1)
	parent.add_child(mesh)
	var t=create_tween(); t.tween_property(mesh,"scale",mesh.scale*1.2,.08); t.tween_property(mesh,"scale",Vector3.ZERO,.15)

func make_afterimage(pos):
	var sprite=Sprite3D.new()
	sprite.texture=load("res://assets/hunter_f.png" if hero.appearance.gender==1 else "res://assets/hunter_m.png")
	sprite.hframes=4; sprite.vframes=4; sprite.frame=5
	sprite.pixel_size=2.45/(sprite.texture.get_width()/4.0)
	sprite.billboard=BaseMaterial3D.BILLBOARD_ENABLED; sprite.modulate=Color(.25,.9,.88,.38)
	sprite.position=pos+Vector3(0,1.17,0); add_child(sprite)
	var t=create_tween(); t.tween_property(sprite,"modulate:a",0.0,.28); t.tween_callback(sprite.queue_free)
