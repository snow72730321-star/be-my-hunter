# Art and motion provenance

Built-in image generation was used, not the API/CLI fallback.
- assets/hunter_m.png: original 4 × 4 male/neutral adult hunter pose atlas, 1254 × 1254 RGBA.
- assets/hunter_f.png: corresponding female preset edit, transparent RGBA.
- assets/seorim_dusk.png: original Korean modern-fantasy blue-hour city background.
- assets/*.svg weapons: BMH source vector art, attached at per-pose hand coordinates.
- World and enemy meshes: authored in scripts/world.gd, not third-party models.
- WAV audio: original deterministic synthesis.

Image prompt set (condensed production record):
1. Four by four transparent production atlas, same adult 25-year-old hunter, teal hair, charcoal long split coat, opaque grey shirt and trousers. Rows: idle/walk, launch/run/brake, windup/swing/followthrough/recover, guard/hit/stagger/cast. Crisp pixel clusters, full-body padding, no text or weapons.
2. Edit the same atlas to adult female body preset. Preserve grid, poses, feet baselines and clothing; shoulder-length teal hair, moderate fully clothed chest, practical proportions, transparent alpha.
3. Wide 16:9 HD-2D Korean neighborhood at blue-hour dusk after rain, layered city depth, warm shop windows, distant cyan gate, dark left negative space, no UI or copied character art.

Motion indices: 0–1 idle, 2–3 walk, 4 launch, 5–6 run, 7 brake, 8 windup, 9 impact, 10 followthrough, 11 recovery, 12 guard, 13 hit, 14 stagger, 15 cast.
Source atlas is retained without destructive repainting. Shader selects frame by UV and recolors distinct hair/skin/cloth regions. Body and chest profiles deform the render mesh only; gameplay stats never read these settings.

The requested Limbus Company influence is in clash rhythm, coin-by-coin hit presentation, anticipation, impact hold, camera response and return to formation. No Limbus images, characters, sound, music or UI files are used.
