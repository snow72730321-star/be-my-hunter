"""Package project.godot at the ZIP root, without machine-specific import caches."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys
root=Path(__file__).resolve().parents[1]
destination=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'BMH_Xogot_Source.zip'
with ZipFile(destination,'w',ZIP_DEFLATED) as archive:
    for path in sorted(root.rglob('*')):
        relative=path.relative_to(root)
        if path.is_file() and not any(p in {'.godot','.git','__pycache__'} for p in relative.parts):
            archive.write(path,relative.as_posix())
print(destination)
