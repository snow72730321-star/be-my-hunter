"""Small transport archives for GitHub browser uploads; CI assembles one native ZIP."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
out=root.parent
art=[['hunter_sd_f.png','hunter_sd_m.png'],['hunter_field_f.png','hunter_field_m.png'],['weapons_detail.png','enemy_sentinel.png'],['arena_cinematic.png'],['city_facades.png','seorim_dusk.png']]
for number,names in enumerate(art,1):
    with ZipFile(out/f'BMH_Art_{number:02}.zip','w',ZIP_DEFLATED) as z:
        for name in names:z.write(root/'assets'/name,'assets/'+name)
with ZipFile(out/'BMH_Xogot_Source.zip','w',ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if p.is_file() and '.godot' not in rel.parts and '__pycache__' not in rel.parts and p.suffix.lower()!='.png':z.write(p,rel.as_posix())
for p in sorted(out.glob('BMH_*.zip')):
    if p.name=='BMH_Xogot_Source.zip' or p.name.startswith('BMH_Art_'):print(p.name,round(p.stat().st_size/1048576,2),'MiB')
