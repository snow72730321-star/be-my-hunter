extends Control
const State=preload("res://scripts/game_state.gd")
const World=preload("res://scripts/world.gd")
const Actor=preload("res://scripts/hunter_actor.gd")
const Joystick=preload("res://scripts/joystick.gd")
const MapView=preload("res://scripts/map_view.gd")
const Sound=preload("res://scripts/sound.gd")
const TEAL=Color("81dbc9")
const GOLD=Color("dfbd7a")
const MUTED=Color("a7a59c")
var model=State.new()
var world
var ui
var overlay
var viewport_container
var scene_viewport
var sound
var screen="title"
var creation_draft={}
var creation_tab=0
var creation_section=0
var preview_sd=false
var active_stick
var battle_link
var skill_cards=[]
var toast_tween
var resizing=false
var preview_actor
var preview_box
var status_label
var goal_label
var resource_label
var near_button
var toast_label
var font
var settings={"sound":true,"shake":true,"flash":true,"text_scale":1.0,"speed":1.0}
var device_panel
var device_tab="map"
var device_body
var waypoint="baek"
var battle_labels={}
var battle_return=Vector3.ZERO
var selected_skill=""
var target="clash"
var display_hp=0
var display_enemy_hp=0
var animation_speed=1.0
var screenshot_mode=false
var ui_clock=0.0

func _ready():
	font=preload("res://scripts/fonts.gd").korean()
	if FileAccess.file_exists("user://bmh_settings.json"):
		var saved=JSON.parse_string(FileAccess.get_file_as_string("user://bmh_settings.json"))
		if saved is Dictionary:
			for key in settings:
				if saved.has(key): settings[key]=saved[key]
	var theme_resource=Theme.new(); theme_resource.default_font=font; theme_resource.default_font_size=22; theme=theme_resource
	viewport_container=SubViewportContainer.new(); viewport_container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	viewport_container.stretch=true; viewport_container.stretch_shrink=1; viewport_container.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	viewport_container.mouse_filter=Control.MOUSE_FILTER_IGNORE; add_child(viewport_container)
	scene_viewport=SubViewport.new(); scene_viewport.size=Vector2i(1280,720); scene_viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	scene_viewport.msaa_3d=Viewport.MSAA_DISABLED; viewport_container.add_child(scene_viewport)
	world=World.new(); scene_viewport.add_child(world)
	world.near_changed.connect(on_near); world.moved.connect(on_move)
	sound=Sound.new(); add_child(sound); sound.set_enabled(settings.sound)
	ui=Control.new(); ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); ui.mouse_filter=Control.MOUSE_FILTER_IGNORE; add_child(ui)
	overlay=Control.new(); overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); overlay.mouse_filter=Control.MOUSE_FILTER_IGNORE; add_child(overlay)
	creation_draft=model.draft(); world.set_appearance(creation_draft)
	show_title()
	get_viewport().size_changed.connect(on_viewport_changed)
	if OS.get_cmdline_user_args().has("--qa"): call_deferred("run_qa")

func dims():
	var rect=get_viewport_rect().size
	return Vector2(maxf(1100,rect.x-56),rect.y)

func on_viewport_changed():
	if resizing:return
	resizing=true
	call_deferred("relayout_screen")

func relayout_screen():
	resizing=false
	if ui==null:return
	ui.position.x=28;overlay.position.x=28
	if screen=="battle" and not model.s.battle.is_empty() and model.s.battle.phase!="PLAN":return
	match screen:
		"title":show_title()
		"creation":show_creation()
		"battle":build_battle_ui()
		"world":
			var was_open=is_instance_valid(device_panel)
			reset_overlay();build_hud()
			if was_open:open_device()

func clear_children(node):
	for child in node.get_children():
		node.remove_child(child); child.queue_free()

func style(color="171b23",border="504936",radius=3):
	var st=StyleBoxFlat.new(); st.bg_color=Color(color); st.border_color=Color(border)
	st.set_border_width_all(1); st.set_corner_radius_all(radius)
	st.content_margin_left=12; st.content_margin_right=12; st.content_margin_top=7; st.content_margin_bottom=7
	return st

func panel(parent,rect,color="141920",border="4d493c"):
	var p=Panel.new(); p.position=rect.position; p.size=rect.size; p.add_theme_stylebox_override("panel",style(color,border,4)); parent.add_child(p); return p

func label(parent,text_value,font_size=22,color=Color("e4ede9")):
	var l=Label.new(); l.text=text_value; l.add_theme_font_size_override("font_size",int(font_size*float(settings.text_scale)))
	l.add_theme_color_override("font_color",color); l.mouse_filter=Control.MOUSE_FILTER_IGNORE; parent.add_child(l); return l

func at_label(parent,text_value,pos,font_size=22,color=Color("e4ede9")):
	var l=label(parent,text_value,font_size,color); l.position=pos; return l

func button(parent,text_value,fn,width=0,height=48,accent=false):
	var b=Button.new(); b.text=text_value; b.custom_minimum_size=Vector2(width,height)
	b.add_theme_stylebox_override("normal",style("403829" if accent else "20242b","bc9a60" if accent else "514d43"))
	b.add_theme_stylebox_override("hover",style("36342f","c6ad75"))
	b.add_theme_stylebox_override("pressed",style("514737","e8d49e"))
	b.add_theme_stylebox_override("disabled",style("15191d","303337"))
	b.add_theme_color_override("font_color",GOLD if accent else Color("dfeae7"))
	b.add_theme_color_override("font_disabled_color",Color("536d78"))
	b.add_theme_font_size_override("font_size",int(19*float(settings.text_scale)))
	b.pressed.connect(func(): sound.effect("ui"); fn.call())
	parent.add_child(b); return b

func at_button(parent,text_value,rect,fn,accent=false):
	var b=button(parent,text_value,fn,rect.size.x,rect.size.y,accent); b.position=rect.position; b.size=rect.size; return b

func vbox(parent,pos,width):
	var b=VBoxContainer.new(); b.position=pos; b.custom_minimum_size.x=width; b.size.x=width; b.add_theme_constant_override("separation",10); parent.add_child(b); return b

func paragraph(parent,text_value,width,font_size=21,color=Color("c8d9d9")):
	var l=label(parent,text_value,font_size,color); l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; l.custom_minimum_size.x=width; l.size.x=width; return l

func background(parent,opacity=1.0):
	var t=TextureRect.new(); t.texture=load("res://assets/seorim_dusk.png"); t.expand_mode=TextureRect.EXPAND_IGNORE_SIZE; t.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED
	t.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); t.modulate.a=opacity; t.mouse_filter=Control.MOUSE_FILTER_IGNORE; parent.add_child(t)
	return t

func shade(parent,alpha=.75):
	var c=ColorRect.new(); c.color=Color(.012,.03,.05,alpha); c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); parent.add_child(c); return c

func reset_overlay():
	clear_children(overlay); device_panel=null

func show_title():
	ui.position.x=28;overlay.position.x=28
	screen="title"; world.can_move=false; world.virtual_input=Vector2.ZERO
	clear_children(ui); reset_overlay(); background(ui)
	var w=dims().x; var h=dims().y
	at_label(ui,"B M H   /   S E O R I M   2 0 5 0",Vector2(70,h*.18),20,TEAL)
	at_label(ui,"BE MY\nHUNTER",Vector2(64,h*.24),76,Color("f2e6cd"))
	at_label(ui,"돌아갈 곳을 지키는 사람",Vector2(72,h*.55),22,Color("a3bdc1"))
	var menu=vbox(ui,Vector2(72,h*.65),310)
	button(menu,"새로하기",func(): creation_draft=model.draft(); creation_tab=0; show_creation(),310,52,true)
	var resume=button(menu,"이어하기",resume_game,310,52)
	resume.disabled=not (model.has_save("auto") or model.has_save("manual"))
	button(menu,"설정",func(): show_settings(false),310,52)
	at_label(ui,"2.5D PIXEL RPG  ·  NATIVE GODOT / XOGOT",Vector2(w-465,h-44),17,MUTED)

func resume_game():
	var slot="auto" if model.has_save("auto") else "manual"
	if not model.load_slot(slot): toast(model.error); return
	begin_world(true)

func creation_preview():
	var p=panel(ui,Rect2(26,119,350,dims().y-224),"10141bd9","5b5141")
	at_label(p,"HUNTER  /  001",Vector2(22,18),14,GOLD)
	var ornament=load("res://scripts/ornament.gd").new();ornament.position=Vector2(0,50);ornament.size=Vector2(350,p.size.y-120);p.add_child(ornament)
	preview_box=SubViewportContainer.new();preview_box.position=Vector2(8,62);preview_box.size=Vector2(334,p.size.y-148);preview_box.stretch=true;preview_box.stretch_shrink=1
	preview_box.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR;preview_box.mouse_filter=Control.MOUSE_FILTER_IGNORE;p.add_child(preview_box)
	var view=SubViewport.new();view.size=Vector2i(334,350);view.transparent_bg=true;view.own_world_3d=true;preview_box.add_child(view)
	var root=Node3D.new();view.add_child(root)
	preview_actor=Actor.new();root.add_child(preview_actor);preview_actor.set_combat_mode(preview_sd);preview_actor.apply_appearance(creation_draft);preview_actor.weapon_root.visible=false
	var cam=Camera3D.new();cam.projection=Camera3D.PROJECTION_ORTHOGONAL;cam.size=3.0;cam.position=Vector3(0,1.22,5);cam.current=true;root.add_child(cam)
	at_button(p,"필드"+ (" ✓" if not preview_sd else ""),Rect2(25,p.size.y-65,141,41),func():preview_sd=false;show_creation(),not preview_sd)
	at_button(p,"전투 SD"+(" ✓" if preview_sd else ""),Rect2(182,p.size.y-65,141,41),func():preview_sd=true;show_creation(),preview_sd)

func show_creation():
	screen="creation";world.can_move=false;clear_children(ui);reset_overlay();background(ui);shade(ui,.78)
	var w=dims().x;var h=dims().y
	at_label(ui,"CREATE YOUR HUNTER",Vector2(28,20),15,GOLD)
	at_label(ui,"나의 헌터",Vector2(27,43),34,Color("f0e7d2"))
	at_label(ui,"당신의 이야기가 시작되는 모습",Vector2(226,60),16,MUTED)
	at_button(ui,"돌아가기",Rect2(w-148,32,116,44),show_title)
	creation_preview()
	var pane=panel(ui,Rect2(397,119,w-423,h-224),"141920e8","61543e")
	var tabs=HBoxContainer.new();tabs.position=Vector2(0,-56);tabs.add_theme_constant_override("separation",8);pane.add_child(tabs)
	button(tabs,"01  커스터마이징",func():creation_tab=0;show_creation(),218,44,creation_tab==0)
	button(tabs,"02  특성",func():creation_tab=1;show_creation(),150,44,creation_tab==1)
	if creation_tab==0:creation_custom(pane)
	else:creation_traits(pane)
	var result=model.creation(creation_draft)
	var footer=panel(ui,Rect2(26,h-86,w-52,65),"15191fee","6b5a3b")
	at_label(footer,"POINTS   %d / %d"%[result.spent,result.budget],Vector2(20,13),20,GOLD)
	at_label(footer,"남음 %d   ·   HP %d   MP %d"%[result.remaining,result.hp,result.mp],Vector2(234,17),18,TEAL if result.valid else Color("ed9d89"))
	at_button(footer,"최종 확인  →",Rect2(w-267,10,185,45),review_creation,true)

func dropdown(parent,title,options,key,pos,width=280):
	at_label(parent,title,pos,19,MUTED)
	var b=OptionButton.new(); b.position=pos+Vector2(0,30); b.size=Vector2(width,43)
	for option in options: b.add_item(option)
	b.selected=int(creation_draft[key]); b.add_theme_stylebox_override("normal",style("1a3440","42626e")); b.add_theme_font_size_override("font_size",21)
	parent.add_child(b)
	b.item_selected.connect(func(index): creation_draft[key]=index; update_creation_preview())
	return b

func creation_custom(p):
	var nav=HBoxContainer.new();nav.position=Vector2(22,18);nav.add_theme_constant_override("separation",8);p.add_child(nav)
	for i in range(3):button(nav,["인물","외형 · 색상","배경"][i],func():creation_section=i;show_creation(),(p.size.x-60)/3,42,creation_section==i)
	var scroll=ScrollContainer.new();scroll.position=Vector2(24,82);scroll.size=p.size-Vector2(48,103);p.add_child(scroll)
	var box=VBoxContainer.new();box.size_flags_horizontal=Control.SIZE_EXPAND_FILL;box.add_theme_constant_override("separation",18);scroll.add_child(box)
	var width=p.size.x-62
	if creation_section==0:
		label(box,"이름",16,MUTED)
		var name_box=LineEdit.new();name_box.text=creation_draft.name;name_box.placeholder_text="헌터의 이름";name_box.max_length=20;name_box.custom_minimum_size=Vector2(width,48);name_box.add_theme_stylebox_override("normal",style("11151c","796241"));name_box.add_theme_font_size_override("font_size",25);box.add_child(name_box)
		name_box.text_changed.connect(func(value):creation_draft.name=value)
		creation_choices(box,"성별",["남성","여성","중성 외형"],"gender",width)
		creation_choices(box,"키",["아담한 키","보통 키","큰 키"],"height",width)
		creation_choices(box,"체형",["가느다란 체형","균형 잡힌 체형","탄탄한 체형"],"body",width)
		if creation_draft.gender==1:creation_choices(box,"가슴 크기 · 의복 안의 체형",["작게","보통","크게"],"chest",width)
		paragraph(box,"성인 25세 · 외형은 전투 능력이나 특성 포인트에 영향을 주지 않아요.",width,15,MUTED)
	elif creation_section==1:
		creation_choices(box,"머리 볼륨",["차분하게","기본","풍성하게"],"hair",width)
		creation_swatches(box,"머리색","hair_color",Actor.HAIR,width)
		creation_swatches(box,"피부색","skin",Actor.SKIN,width)
		creation_swatches(box,"의상색","coat",Actor.COAT,width)
		creation_swatches(box,"눈동자","eyes",[Color("30bf9c"),Color("6fa8ed"),Color("b494ef"),Color("c48b4e")],width)
	else:
		label(box,"각성 이전의 일상",23,GOLD)
		var names=["협회 현장지원 인력","장비 상점 견습","차원교류 구역 주민","침식지역 피난민","연구기관 보조 인력"]
		var details=["통제선과 귀환 경로에 익숙하다.","수리점의 장부와 납품 물건을 기억한다.","서로 다른 문화가 만나는 동네에 살았다.","돌아갈 집과 남은 사람들의 이름을 기억한다.","기록과 측정 장비를 다루는 일을 했다."]
		for i in range(names.size()):
			button(box,("◆  " if creation_draft.background==i else "◇  ")+names[i]+"\n"+details[i],func():creation_draft.background=i;show_creation(),width,66,creation_draft.background==i)
		paragraph(box,"무기와 전투 계열은 게임을 시작한 뒤 장비 화면에서 자유롭게 바꿀 수 있어요.",width,16,MUTED)

func creation_choices(parent,title,choices,key,width):
	label(parent,title,16,MUTED)
	var row=HBoxContainer.new();row.add_theme_constant_override("separation",8);parent.add_child(row)
	for i in range(choices.size()):
		button(row,choices[i],func():creation_draft[key]=i;show_creation(),(width-8*(choices.size()-1))/choices.size(),43,int(creation_draft.get(key,0))==i)

func creation_swatches(parent,title,key,colors,width):
	label(parent,title,16,MUTED)
	var row=HBoxContainer.new();row.add_theme_constant_override("separation",12);parent.add_child(row)
	for i in range(colors.size()):
		var b=button(row,"✓" if int(creation_draft.get(key,0))==i else "",func():creation_draft[key]=i;show_creation(),56,46)
		b.add_theme_stylebox_override("normal",style(colors[i].to_html(),"ecd59c" if int(creation_draft.get(key,0))==i else "3a3b3e",3))
		b.add_theme_color_override("font_color",Color.WHITE)

func update_creation_preview():
	if is_instance_valid(preview_actor): preview_actor.apply_appearance(creation_draft)
	# Rebuild fields when sex changes so dependent chest control is accurate.
	if creation_tab==0:
		var previous_gender=ui.get_meta("gender",-1)
		if previous_gender!=creation_draft.gender:
			ui.set_meta("gender",creation_draft.gender)
			show_creation()

func creation_traits(p):
	var result=model.creation(creation_draft)
	at_label(p,"기본 12 + 불리 보상 %d = 총 %d   /   불리 %d/3"%[result.bonus,result.budget,result.negative],Vector2(20,16),21,GOLD)
	var scroll=ScrollContainer.new(); scroll.position=Vector2(17,56); scroll.size=p.size-Vector2(34,72); p.add_child(scroll)
	var rows=VBoxContainer.new(); rows.size_flags_horizontal=Control.SIZE_EXPAND_FILL; rows.add_theme_constant_override("separation",7); scroll.add_child(rows)
	for t in model.traits:
		var selected=creation_draft.traits.has(t.id)
		var row=HBoxContainer.new(); rows.add_child(row)
		var prefix="✓ " if selected else "+ "
		var price="보상 +%d"%t.points if t.points>0 else "%d점"%t.cost
		button(row,prefix+t.name+"  ·  "+price,func(): toggle_trait(t.id),330,52,selected)
		var desc=paragraph(row,t.desc,maxf(190,p.size.x-400),16,MUTED); desc.size_flags_vertical=Control.SIZE_SHRINK_CENTER

func toggle_trait(id):
	if creation_draft.traits.has(id): creation_draft.traits.erase(id)
	else: creation_draft.traits.append(id)
	if creation_draft.traits.has("tree"):creation_draft.discipline=1
	elif creation_draft.traits.has("demon"):creation_draft.discipline=0
	show_creation()

func review_creation():
	var r=model.creation(creation_draft)
	if not r.valid: toast(", ".join(r.violations)); return
	reset_overlay(); shade(overlay,.8)
	var p=panel(overlay,Rect2((dims().x-680)/2,75,680,560),"122b36","92835f")
	var box=vbox(p,Vector2(30,25),620)
	label(box,"각성 구성 확인",32,GOLD)
	paragraph(box,"%s  ·  성인 %d세\n장비와 전투 계열은 플레이 중 자유롭게 변경"%[creation_draft.name,creation_draft.age],610,23)
	paragraph(box,"HP %d   MP %d   속도 %d~%d\n특성 예산 %d · 사용 %d · 남음 %d"%[r.hp,r.mp,r.speed_min,r.speed_max,r.budget,r.spent,r.remaining],610,23,TEAL)
	var effects=[]
	for id in creation_draft.traits: effects.append(model.trait_def(id).name+": "+model.trait_def(id).desc)
	paragraph(box,"\n".join(effects) if not effects.is_empty() else "선택 특성 없음 · 기본 능력으로 시작합니다.",610,19)
	paragraph(box,"불리 특성은 휴식·정화로 제거되지 않아요. 남은 포인트는 자동으로 돈으로 바뀌지 않아요.",610,18,MUTED)
	button(box,"확정하고 게임 시작",func():
		if model.new_game(creation_draft): begin_world(false),610,54,true)
	button(box,"다시 고르기",reset_overlay,610,44)

func begin_world(loading=false):
	reset_overlay(); clear_children(ui)
	world.set_appearance(model.s.character)
	var p=model.s.position
	world.exit_battle(Vector3(p[0],p[1],p[2]))
	world.apply_state(model)
	screen="world"; world.can_move=true
	sound.start_music()
	build_hud()
	if loading and not model.s.battle.is_empty():
		battle_return=world.player.position
		world.enter_battle(); screen="battle"; build_battle_ui()
	else:
		model.save_slot("auto")
		if not loading: toast("왼쪽 스틱으로 이동 · 가까이서 대화 · 오른쪽 위 헌터 디바이스")

func build_hud():
	clear_children(ui);ui.position.x=28;overlay.position.x=28
	var w=dims().x;var h=dims().y
	var header=panel(ui,Rect2(18,18,290,80),"111720d9","726144")
	at_label(header,model.s.character.name+"   /   HUNTER",Vector2(16,10),19,GOLD)
	resource_label=at_label(header,"",Vector2(16,42),17)
	status_label=at_label(ui,"",Vector2(w*.38,24),17,Color("e2d8c3"))
	goal_label=at_label(ui,"",Vector2(20,118),18,Color("efe2c3"))
	goal_label.add_theme_color_override("font_shadow_color",Color("080b10"));goal_label.add_theme_constant_override("shadow_offset_y",2)
	var device=at_button(ui,"H D\n헌터 단말기",Rect2(w-140,18,118,88),open_device,true);device.add_theme_font_size_override("font_size",17)
	active_stick=Joystick.new();ui.add_child(active_stick);active_stick.direction_changed.connect(func(v):world.virtual_input=v)
	near_button=at_button(ui,"상호작용",Rect2(w-214,h-95,192,65),interact,true)
	at_button(ui,"대시",Rect2(w-112,h-162,90,50),func():world.dash())
	at_label(ui,"왼쪽 빈 화면을 터치하여 이동",Vector2(22,h-45),14,Color("b4b5b0"))
	refresh_hud()

func refresh_hud():
	if model.s.is_empty() or not is_instance_valid(resource_label): return
	var s=model.s
	resource_label.text="HP %d/%d   MP %d/%d"%[s.hp,s.max_hp,s.mp,s.max_mp]
	var day=int(s.time/1440)+1
	status_label.text="서림 생활권   ·   DAY %02d  %02d:%02d"%[day,(9+int(s.time/60))%24,int(s.time)%60]
	var goal="백도식에게 가서 오늘의 부탁을 받으세요"
	if s.world.stage==1: goal="협회의 이지안에게 각성을 등록하세요"
	elif s.world.stage==2: goal="이지안에게 전투 교육을 받으세요"
	elif s.world.stage==3: goal="북동쪽 게이트에서 첫 공략을 시작하세요"
	elif s.world.chapter==1:
		if s.world.outcome=="PENDING":
			var left=maxf(0,(float(s.world.gate_started)+4320-s.time)/60)
			goal="구조 · 의료 · 공략을 준비하세요   |   침식 %.1f%%   유예 %.1f시간"%[s.world.erosion,left]
		else: goal="서림: %s  ·  생존자의 후속 이야기를 확인하세요"%model.outcome_name()
	if not waypoint.is_empty() and world.points.has(waypoint):
		var dist=world.player.position.distance_to(world.points[waypoint].position)
		goal+="\n목적지: %s · %.0fm"%[world.points[waypoint].caption,dist]
	goal_label.text=goal

func on_near(id,caption):
	if is_instance_valid(near_button): near_button.text=caption+"  [E]" if not id.is_empty() else "가까이 다가가기"

func on_move(distance):
	if model.s.is_empty(): return
	model.advance(distance*float(model.balance.world.movement_minutes_per_unit))
	var p=world.player.position; model.s.position=[p.x,p.y,p.z]
	if model.s.world.collapsed: world.apply_state(model)

func _process(delta):
	ui_clock+=delta
	if ui_clock>.4:
		ui_clock=0
		if screen=="world": refresh_hud()

func _unhandled_key_input(event):
	if not event is InputEventKey or not event.pressed or event.echo: return
	if screen=="world":
		if event.physical_keycode==KEY_E: interact()
		elif event.physical_keycode==KEY_SPACE: world.dash()
		elif event.physical_keycode==KEY_TAB: open_device()
	if event.physical_keycode==KEY_ESCAPE:
		if is_instance_valid(device_panel): close_device()
		elif overlay.get_child_count()>0: reset_overlay(); world.can_move=screen=="world"

func toast(message):
	if toast_tween!=null and toast_tween.is_valid():toast_tween.kill()
	if is_instance_valid(toast_label): toast_label.queue_free()
	toast_label=Label.new(); toast_label.text=message; toast_label.add_theme_font_size_override("font_size",21)
	toast_label.add_theme_color_override("font_color",GOLD); toast_label.add_theme_color_override("font_shadow_color",Color.BLACK)
	toast_label.add_theme_constant_override("shadow_offset_x",2); toast_label.add_theme_constant_override("shadow_offset_y",2)
	toast_label.position=Vector2(40,dims().y-232); toast_label.mouse_filter=Control.MOUSE_FILTER_IGNORE; add_child(toast_label)
	var t=create_tween();toast_tween=t;t.tween_interval(3.7); t.tween_property(toast_label,"modulate:a",0.0,.4); t.tween_callback(toast_label.queue_free)

func show_dialogue(speaker,words,choices):
	world.can_move=false; world.virtual_input=Vector2.ZERO
	reset_overlay()
	var rows=ceili(choices.size()/2.0)
	var height=190+rows*58
	var p=panel(overlay,Rect2(100,dims().y-height-28,dims().x-200,height),"112735","839681")
	at_label(p,speaker,Vector2(25,18),26,GOLD)
	var desc=at_label(p,words,Vector2(25,60),21)
	desc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; desc.size=Vector2(p.size.x-50,112)
	var grid=GridContainer.new(); grid.columns=2; grid.position=Vector2(23,174); grid.add_theme_constant_override("h_separation",12); grid.add_theme_constant_override("v_separation",8); p.add_child(grid)
	for choice in choices:
		button(grid,choice[0],choice[1],(p.size.x-62)/2,49)

func close_dialogue():
	reset_overlay(); world.can_move=screen=="world"; world.apply_state(model); refresh_hud()

func perform_story(action):
	if model.story(action):
		close_dialogue(); world.apply_state(model)
		var pos=world.player.position; model.s.position=[pos.x,pos.y,pos.z]
		model.save_slot("auto"); toast(model.s.journal.back().text)
	else: toast(model.error if not model.error.is_empty() else "이미 처리했거나 아직 조건이 맞지 않아요.")

func interact():
	if screen!="world" or not world.can_move: return
	var id=world.near_id
	if id.is_empty(): toast("인물이나 표시된 장소 가까이에서 대화할 수 있어요."); return
	var s=model.s; var w=s.world
	match id:
		"baek":
			if s.npc.baek.life!="ALIVE": return
			if w.outcome!="PENDING":
				var words="주소는 바뀌었는데, 장부는 그대로야." if w.ledger else "물건을 보다 보면, 맡긴 사람 얼굴은 떠올라. 이름부터 다시 적으면 돼."
				show_dialogue("백도식",words,[["수리대 마련 · 2시간",func(): perform_story("reopen")],["첫 무기를 살펴본다",func(): toast("처음 쓰던 무기의 손잡이에 작은 수리 흔적이 남았다."); close_dialogue()],["돌아가기",close_dialogue]])
			elif w.chapter==0:
				show_dialogue("백도식","협회에 맡길 장비야. 다녀오면 장부에 표시해 둘게.\n무기는 닦고 넣어. 다음에 쓸 생각이면.",[["장비 전달 · 10분",func(): perform_story("delivery"); waypoint="jian"],["돌아가기",close_dialogue]])
			else:
				show_dialogue("백도식","가게보다… 돌아올 손님 기록을 두고 가는 게 걸려.\n장부를 보존하면 대피 설득 시간이 3시간에서 1시간으로 줄어든다.",[["장부 촬영 · 30분",func(): perform_story("ledger")],["대피 동행 · 1~3시간",func(): perform_story("baek_safe")],["돌아가기",close_dialogue]])
		"jian":
			if w.stage<1:
				show_dialogue("이지안","수리점에서 온 물건이죠? 백도식 씨에게 전달 내역부터 확인해 주세요.",[["돌아가기",close_dialogue]])
			elif w.stage==1:
				show_dialogue("이지안","각성 반응을 확인했어요.\n여기서는 틀리면 다시 해보면 돼요. 현장에서는 모르는 걸 모른다고 말하는 게 먼저예요.",[["협회 등록",func(): perform_story("register")],["돌아가기",close_dialogue]])
			elif w.stage==2:
				show_dialogue("이지안 · 교육실","기술을 고르고 적의 행동 슬롯에 합을 연결해 보세요.\n합 승리로 정신력이 오르고, 충격이 쌓이면 다음 턴 흐트러집니다. 첫 턴의 인형은 공격하지 않아요.",[["안전한 전투 교육",func(): start_encounter(true)],["교육 생략 · 같은 지급품",func(): perform_story("training_done"); waypoint="gate"],["돌아가기",close_dialogue]])
			else:
				show_dialogue("이지안","의료 물자와 주민 위치를 확인해 주세요.\n태오에게는 위치를 확인한 뒤 지원을 보내겠습니다. 메뉴를 읽는 동안 시간은 흐르지 않아요.",[["지도에서 게이트 표시",func(): waypoint="gate"; close_dialogue()],["돌아가기",close_dialogue]])
		"hyejin":
			if w.chapter==0:
				show_dialogue("오혜진","새로 등록하러 왔어요? 처음부터 무리하진 마요. 회복제가 필요하면 말해요.",[["회복제 구매 · 25",buy_potion],["돌아가기",close_dialogue]])
				return
			var words="물자는 있어도 인도가 늦어요. 구매는 빠르지만 돈이 들고, 정식 승인은 시간이 필요해요."
			if w.medicine: words="덕분에 대피소에 약을 보낼 수 있었어요. 보충할 약은 제값을 받아야 해요."
			show_dialogue("오혜진",words,[["지원 물자 구매 · 60 / 30분",func(): perform_story("medicine")],["정식 승인 · 4시간",func(): perform_story("medicine_paper")],["회복제 구매 · 25",buy_potion],["돌아가기",close_dialogue]])
		"taeo":
			if w.chapter==0:
				show_dialogue("박태오","나도 이번에 등록하러 왔어. 언젠가는 누군가를 기다리지 않고 직접 구하러 갈 수 있겠지?",[["같이 무사히 돌아오자",func(): model.record("taeo_first","태오와 무사 귀환을 약속했다."); close_dialogue()],["돌아가기",close_dialogue]])
				return
			var words="동쪽 통제선 너머에 사람이 남아 있어. 위치를 확인하고 지원을 부를 수 있을까?"
			if s.npc.taeo.role=="SUPPORT": words="전투 복귀는 아직 어렵대. 그래도 통신하고 귀환 경로 챙기는 일은 할 수 있어."
			elif s.npc.taeo.role=="LEADER": words="이번엔 귀환 경로부터 확인했어. 다음에도 같이 돌아오자."
			show_dialogue("박태오",words,[["위치 확인·지원 요청 · 3시간",func(): perform_story("taeo_rescued")],["돌아가기",close_dialogue]])
		"manifest":
			if w.chapter==0:
				show_dialogue("서림 정류장","사람들이 출근 버스를 기다립니다. 오늘도 돌아갈 주소가 있는 하루입니다.",[["돌아가기",close_dialogue]])
				return
			show_dialogue("대피소 기록 담당","공식 명단과 실제 거주 인원이 맞지 않습니다.\n명단 조사: 30명, 버스 확보: 60명. 현재 대피 %d / 120명."%w.evacuated,[["누락 명단 조사 · 1시간",func(): perform_story("manifest")],["버스 확보 · 3시간",func(): perform_story("buses")],["돌아가기",close_dialogue]])
		"refuge":
			show_dialogue("남쪽 대피 거점","휴식하면 HP·MP·정신력·흐트러짐을 회복합니다.\n6시간이 지나며, 미처리 게이트의 침식과 사건도 진행됩니다.",[["휴식 · 6시간",func(): model.rest(); close_dialogue(); model.save_slot("auto"); toast("휴식을 마쳤어요. 디바이스의 지역 상태를 확인하세요.")],["돌아가기",close_dialogue]])
		"gate":
			if w.stage<3:
				show_dialogue("게이트 통제선","협회 등록과 교육을 마친 뒤 감독 인력에게 진입을 보고하세요.",[["돌아가기",close_dialogue]])
			else:
				show_dialogue("침략형 게이트","확인 등급 E · 내부 미확인\n최초 진입 때 1% 레드 변이가 판정되어 저장됩니다. 변이 시 보고·철수 경로를 사용할 수 있어요.",[["진입",gate_entry],["돌아가기",close_dialogue]])

func buy_potion():
	if model.s.money<25: toast("25 크레딧이 필요해요."); return
	model.s.money-=25; model.s.potions+=1; model.advance(5); model.save_slot("auto"); toast("회복제 +1 · 25 크레딧 사용")

func gate_entry():
	if model.enter_gate():
		show_dialogue("디바이스 · 현장 보고","외부 측정과 다른 반응을 확인했습니다. 레드 변이입니다.\n감독 인력에게 보고하고 안전하게 철수할 수 있습니다.",[["보고·지원 대기 · 3시간",func(): model.s.world.red_reported=true; model.advance(180); perform_story("first_clear" if model.s.world.chapter==0 else "gate_clear")],["위험을 감수하고 진입",func(): start_encounter(false)],["철수",close_dialogue]])
	else: start_encounter(false)

func open_device():
	if screen!="world": return
	world.can_move=false; world.virtual_input=Vector2.ZERO
	if is_instance_valid(active_stick):active_stick.release();active_stick.set_process_unhandled_input(false)
	reset_overlay();shade(overlay,.50)
	device_panel=panel(overlay,Rect2(dims().x-514,32,484,dims().y-64),"121820fa","ad8e59")
	device_panel.pivot_offset=Vector2(450,device_panel.size.y)
	device_panel.scale=Vector2(.12,.12); device_panel.modulate.a=0
	at_label(device_panel,"HUNTER DEVICE",Vector2(25,20),24,TEAL)
	at_button(device_panel,"×",Rect2(422,12,42,42),close_device)
	at_label(device_panel,"ASSOCIATION NETWORK  /  CONNECTED",Vector2(25,57),13,MUTED)
	var apps=GridContainer.new(); apps.columns=5; apps.position=Vector2(20,88); apps.add_theme_constant_override("h_separation",6); apps.add_theme_constant_override("v_separation",6); device_panel.add_child(apps)
	for app in [["map","지도"],["gates","게이트"],["equipment","장비"],["quests","의뢰"],["status","상태"],["deck","스킬"],["news","뉴스"],["save","저장"],["settings","설정"],["home","메뉴"]]:
		button(apps,app[1],func(): device_tab=app[0]; show_device_content(),84,43,device_tab==app[0])
	device_body=ScrollContainer.new(); device_body.position=Vector2(23,197); device_body.size=Vector2(438,device_panel.size.y-220); device_panel.add_child(device_body)
	show_device_content()
	var tween=create_tween().set_parallel(true)
	tween.tween_property(device_panel,"scale",Vector2.ONE,.38).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.tween_property(device_panel,"modulate:a",1.0,.18)

func close_device():
	if not is_instance_valid(device_panel): return
	var t=create_tween().set_parallel(true)
	t.tween_property(device_panel,"scale",Vector2(.12,.12),.18).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	t.tween_property(device_panel,"modulate:a",0.0,.15)
	await t.finished
	reset_overlay();world.can_move=true
	if is_instance_valid(active_stick):active_stick.set_process_unhandled_input(true)

func show_device_content():
	clear_children(device_body)
	var body=VBoxContainer.new(); body.custom_minimum_size.x=412; body.size_flags_horizontal=Control.SIZE_EXPAND_FILL; body.add_theme_constant_override("separation",12); device_body.add_child(body)
	var s=model.s
	match device_tab:
		"map":
			label(body,"서림 생활권",25,GOLD)
			var map=MapView.new(); map.world=world; map.player_pos=world.player.position; map.selected=waypoint; map.custom_minimum_size=Vector2(380,286); body.add_child(map)
			map.destination.connect(func(id): waypoint=id; toast(world.points[id].caption+"을 목적지로 표시했어요."))
			paragraph(body,"장소를 탭하면 목적지를 표시해요.\n침식 %.1f%% · %s"%[s.world.erosion,model.outcome_name()],380,18,MUTED)
		"gates":
			var report=model.gate_report()
			label(body,"GATE  /  "+report.id,25,GOLD)
			paragraph(body,report.status+"\n외부 측정 "+report.grade,400,22,TEAL)
			paragraph(body,"발생 D%d %02d:%02d\n침식 시작까지 %.1f시간\n현재 침식 %.1f%%"%[int(report.occurred/1440)+1,int(report.occurred/60+9)%24,int(report.occurred)%60,report.remaining/60,report.erosion],400,19)
			paragraph(body,"내부 정보: "+("현장 진입 기록 확보" if report.actual_known else "미확인 · 외부 등급과 다를 수 있음"),400,18,MUTED)
			button(body,"게이트로 길찾기",func():waypoint="gate";close_device();refresh_hud(),400,48).disabled=not report.active
			button(body,"지원 요청" if not report.support else "지원·철수 경로 확인됨",func():model.request_gate_support();model.save_slot("auto");show_device_content(),400,48,true).disabled=not report.active
			paragraph(body,"진입은 게이트 앞에서 결정해요. 실제 내부를 확인하기 전에는 변이를 확정 표시하지 않습니다.",400,16,MUTED)
		"equipment":
			label(body,"LOADOUT  /  장비",25,GOLD)
			paragraph(body,"장착: "+model.weapon_name(s.character.weapon),400,20,TEAL)
			for kind in range(6):
				var row=HBoxContainer.new();body.add_child(row)
				var icon=TextureRect.new();icon.texture=world.hero.weapon_texture(kind);icon.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;icon.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED;icon.custom_minimum_size=Vector2(64,74);row.add_child(icon)
				button(row,("◆ " if s.character.weapon==kind else "◇ ")+model.weapon_name(kind),func():equip_from_device(kind),330,65,s.character.weapon==kind)
			label(body,"전투 계열",21,GOLD)
			for kind in range(4):button(body,("✓ " if s.character.discipline==kind else "")+["무공 · 내공","마법 · 마나","투술 · 오러","이능 · 정신 에너지"][kind],func():model.set_discipline(kind);model.save_slot("auto");show_device_content(),400,42,s.character.discipline==kind)
			paragraph(body,"장비·계열 변경은 생성 포인트를 바꾸지 않아요. 계열별 남은 MP를 보존하며, 전투 중 장비 교체는 제한됩니다.",400,16,MUTED)
		"quests":
			label(body,"내가 남긴 행동",25,GOLD)
			for i in range(s.journal.size()-1,-1,-1):
				var e=s.journal[i]
				paragraph(body,"D%d · %s"%[int(e.at/1440)+1,e.text],380,19)
			label(body,"확인한 근거",23,TEAL)
			for e in s.evidence: paragraph(body,e,380,18)
			if s.evidence.is_empty(): paragraph(body,"아직 현장에서 교차 확인한 근거가 없어요.",380,18,MUTED)
		"status":
			label(body,s.character.name,28,GOLD)
			paragraph(body,"HP %d/%d · MP %d/%d\n정신력 %+d · 흐트러짐 %d/42\n소지금 %d · 회복제 %d"%[s.hp,s.max_hp,s.mp,s.max_mp,s.morale,s.stagger,s.money,s.potions],380,21)
			paragraph(body,"정신력은 코인 확률을 바꾸는 전투 사기예요. 이능의 정신 에너지 MP와 별도로 저장됩니다.",380,18,MUTED)
			for id in s.character.traits: paragraph(body,model.trait_def(id).name+"\n"+model.trait_def(id).desc,380,18)
			for item in s.exclusive_items: label(body,"전용 지급: "+item,18,TEAL)
			button(body,"연공 · 6시간 / 최대 MP +5",practice,380,48)
		"deck":
			label(body,"액티브 편성 %d / 12"%s.deck.size(),25,GOLD)
			paragraph(body,"기술을 눌러 편성·해제해요. 기본 공격·방어·집중은 별도 공통 행동입니다.",380,17,MUTED)
			for definition in model.skills:
				button(body,("✓ " if s.deck.has(definition.id) else "+ ")+definition.name+("" if model.skill_compatible(definition.id) else " [무기 필요]")+" · MP %d"%model.cost(definition.cost),func():
					if s.deck.has(definition.id): s.deck.erase(definition.id)
					elif s.deck.size()<12: s.deck.append(definition.id)
					model.save_slot("auto"); show_device_content(),380,48,s.deck.has(definition.id))
			paragraph(body,"원본 기술 정의는 고정이에요. 숙련도·계열·무기에 따라 실행 때 계산합니다.",380,17,MUTED)
		"news":
			label(body,"현장 소식",25,GOLD)
			if s.news.is_empty(): paragraph(body,"서림은 평소처럼 하루를 시작합니다. 협회 신규 각성자 등록을 진행 중입니다.",380,21)
			for article in s.news: paragraph(body,article,380,20)
		"save":
			label(body,"세계선 저장",25,GOLD)
			paragraph(body,"수동 슬롯은 자동 저장에 덮어쓰이지 않아요. 불러오기 직전에 현재 세계를 별도로 보존합니다.",380,18,MUTED)
			for i in range(3):
				var slot="manual" if i==0 else "manual%d"%i
				var row=HBoxContainer.new(); body.add_child(row)
				button(row,"슬롯 %d 저장"%(i+1),func(): save_from_device(slot,i+1),190,48)
				var load_btn=button(row,"불러오기",func(): load_from_device(slot),180,48)
				load_btn.disabled=not model.has_save(slot)
			button(body,"자동 저장 불러오기",func(): load_from_device("auto"),380,48)
			button(body,"불러오기 전 상태 복원",func(): load_from_device("before_load"),380,48).disabled=not model.has_save("before_load")
		"settings":
			settings_controls(body,true)
		"home":
			label(body,"게임 메뉴",25,GOLD)
			button(body,"저장하고 시작 화면",func(): model.save_slot("auto"); show_title(),380,54,true)
			button(body,"디바이스 닫기",close_device,380,48)

func practice():
	if model.s.character.discipline==3: toast("이능은 기술을 실제로 사용하며 최대 정신 에너지가 성장해요."); return
	model.advance(360); model.s.max_mp+=10 if model.has_trait("demon") else 5; model.s.mp=model.s.max_mp
	model.save_slot("auto"); world.apply_state(model); show_device_content(); toast("수련을 마쳤어요. 6시간이 지났습니다.")

func show_settings(in_game):
	reset_overlay(); shade(overlay,.80)
	var p=panel(overlay,Rect2((dims().x-640)/2,85,640,550))
	var body=vbox(p,Vector2(28,25),584); settings_controls(body,in_game)
	button(body,"닫기",reset_overlay,584,52,true)

func settings_controls(body,in_game):
	label(body,"설정",30,GOLD)
	for option in [["sound","소리"],["shake","화면 흔들림"],["flash","타격 섬광"]]:
		var check=CheckButton.new(); check.text=option[1]; check.button_pressed=settings[option[0]]; check.custom_minimum_size.y=48; body.add_child(check)
		check.toggled.connect(func(value): settings[option[0]]=value; save_settings())
	label(body,"텍스트 크기",21,MUTED)
	var slider=HSlider.new(); slider.min_value=.85; slider.max_value=1.15; slider.step=.05; slider.value=settings.text_scale; slider.custom_minimum_size=Vector2(350,40); body.add_child(slider)
	slider.value_changed.connect(func(value): settings.text_scale=value; save_settings())
	paragraph(body,"가로 화면 권장 · 스틱은 왼쪽, 대화·대시는 오른쪽. 블루투스 키보드도 사용할 수 있어요.",370 if in_game else 550,18,MUTED)

func save_settings():
	var f=FileAccess.open("user://bmh_settings.json",FileAccess.WRITE)
	if f!=null: f.store_string(JSON.stringify(settings)); f.close()
	sound.set_enabled(settings.sound)

func start_encounter(training):
	if is_instance_valid(active_stick):active_stick.release();active_stick.set_process_unhandled_input(false)
	if toast_tween!=null and toast_tween.is_valid():toast_tween.kill()
	if is_instance_valid(toast_label): toast_label.queue_free()
	var pos=world.player.position
	model.s.position=[pos.x,pos.y,pos.z]
	battle_return=pos
	model.save_slot("branch")
	model.start_battle(training)
	reset_overlay(); world.enter_battle(); screen="battle"
	build_battle_ui(); model.save_slot("auto");encounter_transition()

func bar(parent,pos,width,value,maximum,color):
	var b=ProgressBar.new(); b.position=pos; b.size=Vector2(width,12); b.show_percentage=false; b.max_value=maximum; b.value=value
	b.add_theme_stylebox_override("background",style("17252f","283941",2))
	var fill=StyleBoxFlat.new(); fill.bg_color=color; fill.set_corner_radius_all(2); b.add_theme_stylebox_override("fill",fill)
	parent.add_child(b); return b

func build_battle_ui():
	clear_children(ui); reset_overlay(); battle_labels={};skill_cards=[]
	var b=model.s.battle; var s=model.s
	if b.is_empty(): return
	selected_skill=""; target="clash"
	var w=dims().x; var h=dims().y
	ui.position.x=28;overlay.position.x=28
	battle_link=load("res://scripts/battle_link.gd").new();ui.add_child(battle_link)
	at_label(ui,"B M H   /   "+("TRAINING" if b.training else "GATE ENCOUNTER"),Vector2(18,18),15,GOLD)
	at_label(ui,"TURN  %02d"%b.turn,Vector2(18,44),28,Color("f3e9d2"))
	at_label(ui,"PLAN  /  행동을 연결하세요",Vector2(198,50),17,MUTED)
	at_button(ui,"×%d 연출"%animation_speed,Rect2(w-216,18,100,40),func():animation_speed=3.0 if animation_speed==1.0 else 1.0;world.motion_speed=animation_speed;toast("연출 ×%d"%animation_speed))
	at_button(ui,"저장",Rect2(w-106,18,88,40),func(): save_from_device("auto",0))
	var enemy=panel(ui,Rect2(w*.67,100,300,92),"17161cdd","88624e")
	at_label(enemy,"훈련 수호상" if b.training else "경계의 파수자",Vector2(12,8),20,Color("e1c4a7"))
	battle_labels.enemy_hp=bar(enemy,Vector2(12,40),274,b.enemy_hp,b.enemy_max,Color("c86d53"))
	battle_labels.enemy_stagger=bar(enemy,Vector2(12,57),274,b.enemy_stagger,42,GOLD)
	at_label(enemy,"HP %d / %d    흐트러짐 %d / 42"%[b.enemy_hp,b.enemy_max,b.enemy_stagger],Vector2(12,72),12,MUTED)
	var intent={"observe":"관측 · 공격 없음","attack":"경계 타격   ●","heavy":"분쇄 예고   ● ●"}[b.enemy_intent]
	if b.enemy_broken:intent="흐트러짐 · 행동 불가"
	battle_labels.enemy_action=at_button(ui,"%d  |  %s"%[b.enemy_speed,intent],Rect2(w*.67,204,300,48),func():target="clash";refresh_plan(),true)
	at_button(ui,"본체 · 일방 공격",Rect2(w*.67+102,260,198,36),func():target="body";refresh_plan()).add_theme_font_size_override("font_size",14)
	var player_panel=panel(ui,Rect2(18,h-290,298,88),"131c20e8","767058")
	at_label(player_panel,s.character.name+"    SPEED %d"%b.player_speed,Vector2(12,7),19,GOLD)
	battle_labels.hp=bar(player_panel,Vector2(12,38),272,s.hp,s.max_hp,TEAL)
	battle_labels.stagger=bar(player_panel,Vector2(12,55),272,s.stagger,42,GOLD)
	at_label(player_panel,"HP %d/%d    정신력 %+d    흐트러짐 %d"%[s.hp,s.max_hp,s.morale,s.stagger],Vector2(12,69),12,MUTED)
	var common=HBoxContainer.new();common.position=Vector2(331,h-243);common.add_theme_constant_override("separation",6);ui.add_child(common)
	for action in [["basic","기본 공격"],["guard","방어"],["focus","집중"],["potion","회복제"]]:
		button(common,action[1],func():choose_skill(action[0]),93,36).add_theme_font_size_override("font_size",14)
	battle_labels.mp=at_label(ui,"MP %d / %d   ·   예약 0"%[s.mp,s.max_mp],Vector2(334,h-282),17,TEAL)
	battle_labels.plan=at_label(ui,"슬롯 01 → 기술 → 적 행동 슬롯 / 본체",Vector2(334,h-309),16,GOLD)
	var bottom=panel(ui,Rect2(12,h-192,w-24,180),"101319f5","736149")
	battle_labels.slot=at_button(bottom,"01\n미배치",Rect2(10,13,112,152),func():toast("아래 기술을 선택한 뒤 적 행동에 연결하세요."),true)
	var skill_grid=GridContainer.new();skill_grid.columns=6;skill_grid.position=Vector2(134,10);skill_grid.add_theme_constant_override("h_separation",6);skill_grid.add_theme_constant_override("v_separation",6);bottom.add_child(skill_grid)
	var cw=floorf((w-354)/6.0)
	for i in range(12):
		if i<s.deck.size():
			var sk=model.skill(s.deck[i]).duplicate(true);sk.cost=model.cost(sk.cost)
			var card=load("res://scripts/battle_card.gd").new();card.definition=sk;card.icon_kind=int(sk.get("icon_kind",s.character.weapon));card.compatible=model.skill_compatible(sk.id);card.disabled=not card.compatible or sk.cost>s.mp
			card.custom_minimum_size=Vector2(cw,76);card.tooltip_text=sk.name+" · "+("무기 호환" if card.compatible else "현재 무기에서 사용할 수 없음")+" · MP %d"%sk.cost
			skill_grid.add_child(card);card.pressed.connect(func():choose_skill(sk.id));skill_cards.append(card)
		else:
			var empty=button(skill_grid,"—",func():pass,cw,76);empty.disabled=true;empty.modulate.a=.25
	at_label(bottom,"ENGAGE",Vector2(w-176,18),13,MUTED)
	battle_labels.execute=at_button(bottom,"전투 개시  »",Rect2(w-187,45,148,69),execute_turn,true);battle_labels.execute.add_theme_font_size_override("font_size",19);battle_labels.execute.disabled=true
	at_button(bottom,"철수",Rect2(w-187,125,148,36),func():choose_skill("retreat")).add_theme_font_size_override("font_size",14)
	battle_link.from_point=Vector2(80,h-199);battle_link.to_point=Vector2(w*.67+150,252)
	if b.player_broken:toast("흐트러짐: 이번 턴 행동 불가. 다음 턴에 회복해요.")
	if not b.plans.is_empty():selected_skill=b.plans[0].skill;target=b.plans[0].target;refresh_plan()

func choose_skill(id):
	if model.s.battle.phase!="PLAN": return
	selected_skill=id; refresh_plan()

func refresh_plan():
	if selected_skill.is_empty():
		if battle_labels.has("plan"): battle_labels.plan.text="대상: "+("적 행동 슬롯 · 합 연결" if target=="clash" else "적 본체 · 일방 공격")
		return
	if not model.plan_action(selected_skill,target): toast(model.error); return
	var def=model.skill(selected_skill)
	var skill_name=def.name if not def.is_empty() else {"basic":"기본 공격","guard":"방어","focus":"집중","potion":"회복제","retreat":"철수"}.get(selected_skill,selected_skill)
	battle_labels.slot.text="행동 01\n"+skill_name
	var chance=clampf(.5+model.s.morale*.01,.05,.95)*100
	battle_labels.plan.text=skill_name+" → "+("적 행동과 합" if target=="clash" else "적 본체")+"   ·   코인 앞면 %.0f%%"%chance
	battle_labels.mp.text="MP %d / %d   ·   예약 %d"%[model.s.mp,model.s.max_mp,model.s.battle.plans[0].cost]
	battle_labels.execute.disabled=false
	for card in skill_cards:card.chosen=card.definition.id==selected_skill;card.queue_redraw()
	battle_link.shown=target=="clash" and not def.is_empty() and def.get("coins",0)>0
	battle_link.queue_redraw()
	if not def.is_empty() and def.get("coins",0)>0:
		var low=int(def.base);var high=low+int(def.coin)*int(def.coins)
		battle_labels.plan.text+="   ·   기본 합 %d–%d"%[low,high]

func wait_animation(seconds):
	await get_tree().create_timer(seconds/animation_speed).timeout

func combat_banner(words,color=GOLD):
	var l=Label.new(); l.text=words; l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; l.size=Vector2(700,100); l.position=Vector2((dims().x-700)/2,195)
	l.add_theme_font_size_override("font_size",45); l.add_theme_color_override("font_color",color)
	l.add_theme_color_override("font_shadow_color",Color("122334")); l.add_theme_constant_override("shadow_offset_x",3); l.add_theme_constant_override("shadow_offset_y",3)
	l.mouse_filter=Control.MOUSE_FILTER_IGNORE; overlay.add_child(l)
	var t=create_tween(); t.tween_property(l,"position:y",178,.18); t.tween_interval(.22/animation_speed); t.tween_property(l,"modulate:a",0.0,.16); t.tween_callback(l.queue_free)

func floating_damage(amount,enemy_side,head):
	var l=Label.new(); l.text=("◆ " if head else "◇ ")+str(amount)
	l.add_theme_font_size_override("font_size",38); l.add_theme_color_override("font_color",GOLD if enemy_side else Color("f39984")); l.add_theme_color_override("font_shadow_color",Color.BLACK); l.add_theme_constant_override("shadow_offset_x",3); l.add_theme_constant_override("shadow_offset_y",3)
	l.position=Vector2(dims().x*.72 if enemy_side else dims().x*.27,305); overlay.add_child(l)
	var t=create_tween().set_parallel(true); t.tween_property(l,"position:y",245,.5); t.tween_property(l,"modulate:a",0.0,.6); t.chain().tween_callback(l.queue_free)

func impact_flash():
	if not settings.flash: return
	var c=ColorRect.new(); c.color=Color(.63,.89,.89,.18); c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); c.mouse_filter=Control.MOUSE_FILTER_IGNORE; overlay.add_child(c)
	var t=create_tween(); t.tween_property(c,"color:a",0.0,.10); t.tween_callback(c.queue_free)

func execute_turn():
	if model.s.battle.is_empty() or model.s.battle.phase!="PLAN": return
	display_hp=model.s.hp; display_enemy_hp=model.s.battle.enemy_hp
	var events=model.resolve()
	if events.is_empty(): return
	battle_labels.execute.disabled=true
	battle_labels.plan.text="행동 실행 중"
	battle_link.shown=false;battle_link.queue_redraw()
	world.motion_speed=animation_speed
	for e in events:
		match e.type:
			"clash":
				await world.clash_approach()
				show_clash_coins(e)
				combat_banner("%d    CLASH    %d"%[e.a,e.b],TEAL if e.a>e.b else GOLD)
				world.burst(Vector3(130,1.7,.5),"d7cb9f"); sound.effect("clash")
				if settings.shake: world.shake(.12,.13)
				await wait_animation(.65)
				await world.clash_return()
			"hit":
				var present_hit=func(_skill_id):
					if e.player:
						display_hp=maxi(0,display_hp-e.damage);battle_labels.hp.value=display_hp
					else:
						display_enemy_hp=maxi(0,display_enemy_hp-e.damage);battle_labels.enemy_hp.value=display_enemy_hp
					floating_damage(e.damage,not e.player,e.head);sound.effect("hit");impact_flash()
					if settings.shake:world.shake(.20,.16)
				world.impact_presented.connect(present_hit,CONNECT_ONE_SHOT)
				if e.player:await world.strike_player()
				else:await world.strike_enemy(e.motion,e.color,e.get("skill_id","basic"))
				await wait_animation(.12)
			"guard":
				world.hero.set_pose(12); combat_banner("GUARD",TEAL); await wait_animation(.4)
			"recover":
				world.hero.set_pose(15); world.burst(world.player.position+Vector3(0,1,.3),"82d8b8","cast")
				combat_banner(e.text,TEAL); await wait_animation(.7)
			"stagger":
				combat_banner("흐트러짐 · 다음 턴 행동 불가",GOLD)
				if e.player: world.hero.set_pose(14)
				else: world.monster.set_pose(6)
				await wait_animation(.65)
			"skip":
				combat_banner("흐트러짐 회복 대기",MUTED); await wait_animation(.4)
			"escape":
				model.s.battle={}; model.advance(15); end_encounter("철수했습니다. 게이트의 최초 진입 판정은 유지됩니다."); return
			"victory":
				world.monster.set_pose(7);combat_banner("THREAT CLEARED",TEAL); await wait_animation(.85)
			"defeat":
				combat_banner("감독 인력 · 철수 지원",GOLD); await wait_animation(.85)
	var result=model.finish_playback()
	if result=="next":
		world.hero.set_pose(0); world.monster.set_pose(-1)
		build_battle_ui(); model.save_slot("auto")
	else:
		end_encounter("교육을 마쳤습니다." if model.s.world.stage==3 else ("현장 공략을 마쳤습니다. 디바이스에서 결과를 확인하세요." if result=="victory" else "치료 후 복귀했습니다. 시간과 현장 상황을 확인하세요."))

func end_encounter(message):
	world.exit_battle(battle_return); screen="world"; world.can_move=true
	world.apply_state(model); reset_overlay(); build_hud()
	var p=world.player.position; model.s.position=[p.x,p.y,p.z]
	if model.s.world.stage==3: waypoint="gate"
	model.save_slot("auto"); toast(message)

func run_qa():
	# Automated interaction smoke path, invoked only by --qa in the Godot runner.
	screenshot_mode=true
	var out=OS.get_environment("BMH_QA_OUT")
	if out.is_empty(): out="user://qa"
	DirAccess.make_dir_recursive_absolute(out)
	await get_tree().create_timer(1.0).timeout
	await capture(out+"/01-title.png")
	creation_draft=model.draft(); creation_draft.gender=1; creation_draft.weapon=4; creation_draft.coat=0; creation_draft.traits=["steady","vital"]
	show_creation(); await get_tree().create_timer(.5).timeout
	await capture(out+"/02-creation.png")
	preview_sd=true;show_creation();await get_tree().create_timer(.25).timeout;await capture(out+"/02b-creation-sd.png")
	preview_sd=false
	creation_tab=1; show_creation(); await get_tree().create_timer(.3).timeout
	await capture(out+"/03-traits.png")
	assert(model.new_game(creation_draft,77)); begin_world(false)
	world.player.position=Vector3(-1,.08,1); world.camera_anchor=world.player.position
	world.virtual_input=Vector2(-.6,0)
	await get_tree().create_timer(.6).timeout
	world.virtual_input=Vector2.ZERO
	await capture(out+"/04-world.png")
	assert(active_stick.begin(Vector2(180,dims().y-170),7));active_stick.update_direction(Vector2(214,dims().y-176));assert(active_stick.active)
	await capture(out+"/04b-floating-stick.png");active_stick.release();assert(not active_stick.active and world.virtual_input==Vector2.ZERO)
	open_device(); await get_tree().create_timer(.5).timeout
	await capture(out+"/05-device.png")
	device_tab="gates";show_device_content();await get_tree().create_timer(.2).timeout;await capture(out+"/08-gates.png")
	device_tab="equipment";show_device_content();await get_tree().create_timer(.2).timeout;await capture(out+"/09-equipment.png")
	assert(model.equip_weapon(2));world.set_appearance(model.s.character)
	assert(model.equip_weapon(4));world.set_appearance(model.s.character)
	reset_overlay(); model.story("delivery"); model.story("register")
	start_encounter(true);assert(world.hero.combat_mode);await get_tree().create_timer(.4).timeout
	await capture(out+"/06-battle-plan.png")
	choose_skill("flurry")
	execute_turn()
	await world.impact_presented
	await capture(out+"/07-battle-action.png")
	await get_tree().create_timer(4.0).timeout
	while not model.s.battle.is_empty():
		if model.s.battle.phase=="PLAN": choose_skill("basic"); await execute_turn()
		await get_tree().create_timer(.1).timeout
	assert(model.s.world.stage==3);assert(not world.hero.combat_mode)
	# Presentation-only weapon QA never changes campaign HP or rewards.
	for kind in range(6):
		assert(model.equip_weapon(kind));world.set_appearance(model.s.character);world.enter_battle()
		world.strike_enemy("slash","eacb85",["sword_chain","dao_pressure","katana_draw","spear_lunge","fist_chain","focus_cast"][kind])
		await world.impact_presented;await capture(out+"/weapon-%d-impact.png"%kind);await get_tree().create_timer(.8).timeout
		world.exit_battle(battle_return)
	assert(model.equip_weapon(2));world.set_appearance(model.s.character)
	for aspect in [[1560,720,"ultrawide"],[960,720,"tablet"]]:
		get_window().size=Vector2i(aspect[0],aspect[1]);await get_tree().create_timer(.4).timeout
		build_hud();await capture(out+"/aspect-"+aspect[2]+"-world.png")
		start_encounter(true);await get_tree().create_timer(.3).timeout;choose_skill("edge");await capture(out+"/aspect-"+aspect[2]+"-battle.png")
		model.s.battle={};world.exit_battle(battle_return);screen="world";build_hud()
	get_window().size=Vector2i(1280,720);await get_tree().create_timer(.3).timeout
	assert(model.save_slot("manual")); var before=JSON.stringify(model.s)
	assert(model.load_slot("manual")); assert(load("res://tests/compare.gd").same(model.s,JSON.parse_string(before)))
	print("BMH_NATIVE_UI_QA_OK: menu, field/SD appearance, floating joystick, gates, equipment, six weapon motions, 16:9/19.5:9/4:3, clash playback, training, atomic save/load")
	sound.set_enabled(false)
	get_tree().quit.call_deferred(0)

func capture(path):
	await RenderingServer.frame_post_draw
	var picture=get_viewport().get_texture().get_image()
	var err=picture.save_png(path)
	assert(err==OK)

func save_from_device(slot,index):
	if model.save_slot(slot): toast("전투 계획 저장" if index==0 else "슬롯 %d 저장 완료"%index)
	else: toast(model.error)
	if is_instance_valid(device_panel): show_device_content()

func load_from_device(slot):
	if model.load_slot(slot): begin_world(true)
	else: toast(model.error)

func equip_from_device(kind):
	if model.equip_weapon(kind):
		world.set_appearance(model.s.character);model.save_slot("auto");show_device_content()
	else:toast(model.error)

func show_clash_coins(event):
	var p=panel(overlay,Rect2((dims().x-480)/2,105,480,62),"12151ce8","a98c58")
	var a="";var b=""
	for head in event.get("player_heads",[]):a+=("● " if head else "○ ")
	for head in event.get("enemy_heads",[]):b+=("● " if head else "○ ")
	at_label(p,a,Vector2(22,16),25,TEAL);at_label(p,"COIN",Vector2(204,22),14,GOLD);at_label(p,b,Vector2(330,16),25,Color("e4a078"))
	var t=create_tween();t.tween_interval(.57/animation_speed);t.tween_property(p,"modulate:a",0.0,.12/animation_speed);t.tween_callback(p.queue_free)

func encounter_transition():
	var veil=ColorRect.new();veil.color=Color("0b0e14");veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);veil.mouse_filter=Control.MOUSE_FILTER_IGNORE;overlay.add_child(veil)
	var t=create_tween();t.tween_property(veil,"color:a",0.0,.30);t.tween_callback(veil.queue_free)
