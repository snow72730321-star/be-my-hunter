extends Button
var definition={}
var chosen=false
var compatible=true
var compact=false
var icon_kind=0
var icon_texture
var face_font
func _ready():
	text="";mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND
	face_font=preload("res://scripts/fonts.gd").korean()
	icon_texture=AtlasTexture.new();icon_texture.atlas=load("res://assets/weapons_detail.png")
	var cell=icon_texture.atlas.get_size()/Vector2(3,2);var visual=JSON.parse_string(FileAccess.get_file_as_string("res://data/weapon_visuals.json"))[icon_kind]
	var crop=visual.icon;icon_texture.region=Rect2(Vector2(icon_kind%3,floori(icon_kind/3.0))*cell+Vector2(crop[0],crop[1]),Vector2(crop[2],crop[3]))
	for key in ["normal","hover","pressed","focus","disabled"]:add_theme_stylebox_override(key,StyleBoxEmpty.new())
	mouse_entered.connect(queue_redraw);mouse_exited.connect(queue_redraw);pressed.connect(queue_redraw)
func _draw():
	var w=size.x;var h=size.y
	var tint=Color(definition.get("color","bea779"))
	if not compatible:tint=Color("55585c")
	var outline=Color("f5df9e") if chosen else tint.darkened(.32)
	var poly=PackedVector2Array([Vector2(8,0),Vector2(w-8,0),Vector2(w,8),Vector2(w,h-8),Vector2(w-8,h),Vector2(8,h),Vector2(0,h-8),Vector2(0,8),Vector2(8,0)])
	draw_colored_polygon(poly,Color("292524") if chosen else Color("14181f"));draw_polyline(poly,outline,2.4 if chosen else 1.0,true)
	draw_rect(Rect2(7,6,w-14,3),tint)
	if icon_texture!=null:
		draw_texture_rect(icon_texture,Rect2(9,25,29,42),false,Color(1,1,1,1 if compatible else .22))
	if face_font==null:return
	var coins=int(definition.get("coins",0))
	for i in range(coins):
		var at=Vector2(14+i*11,17);draw_circle(at,3.2,Color("ebcc77") if compatible else Color("596068"))
	draw_string(face_font,Vector2(42,h-29),str(definition.get("name","대기")),HORIZONTAL_ALIGNMENT_CENTER,w-48,13,Color("f0e3c9") if compatible else Color("6e7980"))
	draw_string(face_font,Vector2(42,h-10),"%d + %d · MP %d"%[definition.get("base",0),definition.get("coin",0),definition.get("cost",0)],HORIZONTAL_ALIGNMENT_CENTER,w-48,11,Color("b6a88b"))
	if not compatible:draw_line(Vector2(12,37),Vector2(w-12,37),Color("a08073"),1,true)
