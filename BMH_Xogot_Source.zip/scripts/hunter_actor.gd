extends Node3D
const HAIR = [Color("bcb4d6"),Color("343648"),Color("f0dfba"),Color("ca7f92"),Color("69bbae")]
const COAT = [Color("243348"),Color("24554e"),Color("61364a"),Color("bbad93")]
const SKIN = [Color("e4b38f"),Color("c68a64"),Color("8c5a45"),Color("f0cbb1")]
var body_mesh
var material
var weapon_root
var weapon_mesh
var current_frame=0
var facing=1.0
var appearance={}
var clock=0.0
var walking=false
var sprinting=false
var locked_pose=false
var shadow
var visual_scale=1.0
var combat_mode=false
var weapon_kind=4
var weapon_trail_point=Vector3.ZERO
var weapon_angle=0.0
var hand_anchor=Vector2(.30,1.0)

func _ready():
	body_mesh=MeshInstance3D.new()
	var q=QuadMesh.new(); q.size=Vector2(2.45,2.45); q.subdivide_width=20; q.subdivide_depth=20
	body_mesh.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	body_mesh.mesh=q
	material=ShaderMaterial.new(); material.shader=load("res://shaders/hunter.gdshader")
	body_mesh.material_override=material
	body_mesh.position.y=1.17
	add_child(body_mesh)
	shadow=MeshInstance3D.new()
	var sm=CylinderMesh.new(); sm.top_radius=0.5; sm.bottom_radius=0.5; sm.height=0.008; sm.radial_segments=16
	shadow.mesh=sm
	var shade=StandardMaterial3D.new(); shade.albedo_color=Color(0.025,0.04,0.07,0.65); shade.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; shade.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	shadow.material_override=shade; shadow.position.y=0.035; shadow.scale.z=0.55
	add_child(shadow)
	weapon_root=Node3D.new(); add_child(weapon_root)
	if not appearance.is_empty(): apply_appearance(appearance)

func apply_appearance(d):
	appearance=d.duplicate(true)
	if material==null: return
	var prefix="hunter_sd_" if combat_mode else "hunter_field_"
	material.set_shader_parameter("atlas",load("res://assets/"+prefix+("f.png" if d.gender==1 else "m.png")))
	material.set_shader_parameter("sd_mode",1.0 if combat_mode else 0.0)
	var eye_palette=[Color("30bf9c"),Color("6fa8ed"),Color("b494ef"),Color("c48b4e")]
	material.set_shader_parameter("eye_color",eye_palette[int(d.get("eyes",0))%4])
	material.set_shader_parameter("hair_color",HAIR[int(d.hair_color)%HAIR.size()])
	material.set_shader_parameter("coat_color",COAT[int(d.coat)%COAT.size()])
	material.set_shader_parameter("skin_color",SKIN[int(d.skin)%SKIN.size()])
	material.set_shader_parameter("chest",float(d.chest-1) if d.gender==1 else 0.0)
	material.set_shader_parameter("hair_style",float(d.hair)-1.0)
	scale=Vector3([0.88,1.0,1.12][int(d.body)],[0.91,1.0,1.10][int(d.height)],1.0)*visual_scale
	build_weapon(int(d.weapon))
	set_pose(current_frame)

func set_combat_mode(value):
	combat_mode=value
	if not appearance.is_empty(): apply_appearance(appearance)

func weapon_texture(kind):
	var texture=AtlasTexture.new(); texture.atlas=load("res://assets/weapons_detail.png")
	var cell=texture.atlas.get_size()/Vector2(3,2)
	texture.region=Rect2(Vector2(kind%3,floori(kind/3.0))*cell,cell)
	return texture

func build_weapon(kind):
	weapon_kind=kind
	for child in weapon_root.get_children(): child.queue_free()
	weapon_mesh=Sprite3D.new(); weapon_mesh.texture=weapon_texture(kind)
	var visual=JSON.parse_string(FileAccess.get_file_as_string("res://data/weapon_visuals.json"))[kind]
	weapon_mesh.pixel_size=float(visual.pixel_size)
	weapon_mesh.billboard=BaseMaterial3D.BILLBOARD_DISABLED
	weapon_mesh.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR
	weapon_mesh.alpha_cut=SpriteBase3D.ALPHA_CUT_DISCARD
	weapon_mesh.alpha_scissor_threshold=.48
	# Shift the texture upward so the lower grip, not the blade center, sits in the palm.
	weapon_mesh.offset=Vector2(256-float(visual.grip[0]),float(visual.grip[1])-256)
	weapon_mesh.render_priority=2
	weapon_root.add_child(weapon_mesh)


func set_pose(index):
	current_frame=index
	if material==null: return
	material.set_shader_parameter("frame",float(index))
	material.set_shader_parameter("flipped",1.0 if facing<0 else 0.0)
	var hand=[Vector2(.30,1.0),Vector2(.30,1.0),Vector2(.47,1.0),Vector2(.30,1.05),Vector2(.67,.75),Vector2(.67,.9),Vector2(.70,.9),Vector2(.65,1.15),Vector2(-.36,1.6),Vector2(.8,1.5),Vector2(.70,.8),Vector2(.55,1.25),Vector2(.15,1.3),Vector2(.3,.9),Vector2(.2,.5),Vector2(.7,1.5)]
	if combat_mode:
		hand=[Vector2(.53,.82),Vector2(.53,.82),Vector2(.72,.85),Vector2(.74,.9),Vector2(.82,.35),Vector2(.85,.7),Vector2(.85,.65),Vector2(.88,1.14),Vector2(-.20,2.08),Vector2(1.00,1.16),Vector2(1.0,1.02),Vector2(.54,1.05),Vector2(.32,1.12),Vector2(.24,.76),Vector2(.35,.3),Vector2(1.00,1.3)]
	hand_anchor=hand[index]
	weapon_root.position=Vector3(hand_anchor.x*facing,hand_anchor.y,.18)
	weapon_mesh.flip_h=facing<0
	weapon_angle=([-0.3,-0.3,-.6,-.8,-1.4,-1.4,-1.4,-.5,.85,-1.6,-2.4,-.65,.2,1.0,.1,-.5][index])*facing

func _process(delta):
	clock+=delta
	var cam=get_viewport().get_camera_3d()
	if cam!=null and weapon_root!=null:
		var basis=cam.global_transform.basis
		weapon_root.global_position=body_mesh.global_position+basis.x*hand_anchor.x*facing*global_basis.get_scale().x+basis.y*(hand_anchor.y-1.17)*global_basis.get_scale().y+basis.z*.06
		weapon_root.global_basis=(basis*Basis(Vector3(0,0,1),weapon_angle)).scaled(global_basis.get_scale())
	if not locked_pose:
		if walking: set_pose((5 if int(clock*10)%2==0 else 6) if sprinting else (2 if int(clock*7)%2==0 else 3))
		else: set_pose(0 if int(clock*1.6)%2==0 else 1)

func hit_flash():
	material.set_shader_parameter("flash",0.9)
	var t=create_tween()
	t.tween_method(func(v): material.set_shader_parameter("flash",v),0.9,0.0,0.22)
