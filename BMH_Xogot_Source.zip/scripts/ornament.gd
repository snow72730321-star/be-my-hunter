extends Control
var accent=Color("c2a365")
func _ready():mouse_filter=Control.MOUSE_FILTER_IGNORE
func _draw():
	var c=size*.5;var r=minf(size.x,size.y)*.38
	draw_arc(c,r,0,TAU,128,Color(accent,.22),1,true)
	draw_arc(c,r*.93,-PI*.72,PI*.2,80,Color(accent,.40),2,true)
	for i in range(36):
		var v=Vector2.from_angle(i*TAU/36);draw_line(c+v*r,c+v*(r+7 if i%3==0 else r+3),Color(accent,.35),1,true)
	for k in [-1,1]:draw_line(Vector2(20,c.y+k*r*.73),Vector2(size.x-20,c.y+k*r*.73),Color(accent,.08),1,true)
