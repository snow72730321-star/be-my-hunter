extends Control
signal direction_changed(direction)
var direction=Vector2.ZERO
var active=false
var enabled=true
var touch_id=-1
var center=Vector2.ZERO
var radius=58.0
func _ready():
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
func _draw():
	if not active:return
	draw_circle(center,radius,Color(.03,.04,.06,.34))
	draw_arc(center,radius,0,TAU,64,Color(.90,.79,.55,.46),1.5,true)
	draw_circle(center+direction*38,23,Color(.85,.78,.62,.24))
	draw_arc(center+direction*38,23,0,TAU,48,Color(.98,.89,.70,.8),1.5,true)
func allowed(p):
	return p.x>=24 and p.x<size.x*.47 and p.y>size.y*.35 and p.y<size.y-18
func set_enabled(value):
	enabled=value
	if not enabled:release()
func begin(p,index):
	if not enabled or active or not allowed(p):return false
	active=true;touch_id=index;center=p;direction=Vector2.ZERO
	direction_changed.emit(direction);queue_redraw();return true
func local_point(event):
	return get_global_transform_with_canvas().affine_inverse()*event.position
func update_direction(p):
	var delta=p-center
	if delta.length()>radius*1.75:center=p-delta.normalized()*radius*1.75
	direction=((p-center)/radius).limit_length()
	if direction.length()<.13:direction=Vector2.ZERO
	direction_changed.emit(direction);queue_redraw()
func _unhandled_input(event):
	# GUI gets first refusal for gesture starts; an empty world surface passes through.
	if not enabled or active:return
	if event is InputEventScreenTouch and event.pressed and not event.canceled:
		if begin(local_point(event),event.index):get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT and event.pressed and event.device!=-1:
		if begin(local_point(event),-2):get_viewport().set_input_as_handled()
func _input(event):
	# Retain the captured finger until release, including release over HUD buttons.
	# Other fingers continue to the GUI (dash/device) without stealing movement.
	if not enabled or not active:return
	var captured=false
	if event is InputEventScreenTouch and event.index==touch_id:
		if not event.pressed or event.canceled:release()
		captured=true
	elif event is InputEventScreenDrag and event.index==touch_id:
		update_direction(local_point(event));captured=true
	elif event is InputEventMouseButton and event.device!=-1 and touch_id==-2 and event.button_index==MOUSE_BUTTON_LEFT:
		if not event.pressed:release()
		captured=true
	elif event is InputEventMouseMotion and event.device!=-1 and touch_id==-2:
		update_direction(local_point(event));captured=true
	if captured:get_viewport().set_input_as_handled()
func release():
	active=false;touch_id=-1;direction=Vector2.ZERO;direction_changed.emit(direction);queue_redraw()
func _notification(what):
	if what==NOTIFICATION_APPLICATION_FOCUS_OUT:release()
func _exit_tree():
	release()
