extends Control
signal direction_changed(direction)
var direction=Vector2.ZERO
var active=false
var touch_id=-1
var center=Vector2.ZERO
var radius=58.0
func _ready():
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
func _draw():
	if not active: return
	draw_circle(center,radius,Color(.03,.04,.06,.34))
	draw_arc(center,radius,0,TAU,64,Color(.90,.79,.55,.46),1.5,true)
	draw_circle(center+direction*38,23,Color(.85,.78,.62,.24))
	draw_arc(center+direction*38,23,0,TAU,48,Color(.98,.89,.70,.8),1.5,true)
func allowed(p):
	# Only the unoccupied lower-left world surface can start a movement gesture.
	return p.x>=24 and p.x<size.x*.47 and p.y>size.y*.35 and p.y<size.y-18
func begin(p,index):
	if active or not allowed(p): return false
	active=true; touch_id=index; center=p; direction=Vector2.ZERO
	direction_changed.emit(direction); queue_redraw(); return true
func update_direction(p):
	var delta=p-center
	if delta.length()>radius*1.75: center=p-delta.normalized()*radius*1.75
	direction=((p-center)/radius).limit_length()
	if direction.length()<.13: direction=Vector2.ZERO
	direction_changed.emit(direction); queue_redraw()
func _unhandled_input(event):
	if event is InputEventScreenTouch:
		var p=get_global_transform_with_canvas().affine_inverse()*event.position
		if event.pressed:
			if begin(p,event.index): get_viewport().set_input_as_handled()
		elif event.index==touch_id: release(); get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and active and event.index==touch_id:
		update_direction(get_global_transform_with_canvas().affine_inverse()*event.position); get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT and event.device!=-1:
		if event.pressed:
			if begin(get_local_mouse_position(),-2): get_viewport().set_input_as_handled()
		elif touch_id==-2: release()
	elif event is InputEventMouseMotion and active and touch_id==-2:
		update_direction(get_local_mouse_position()); get_viewport().set_input_as_handled()
func release():
	active=false; touch_id=-1; direction=Vector2.ZERO; direction_changed.emit(direction); queue_redraw()
func _notification(what):
	if what==NOTIFICATION_APPLICATION_FOCUS_OUT: release()
