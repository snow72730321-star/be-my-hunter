extends RefCounted
# Definition data is immutable; all mutable values live in one campaign snapshot.
var balance = {}
var traits = []
var skills = []
var s = {}
var error = ""
var save_dir = "user://"

func _init():
	balance = read_json("res://data/balance.json")
	traits = read_json("res://data/traits.json")
	skills = read_json("res://data/skills.json")

func read_json(path):
	if not FileAccess.file_exists(path):
		return {}
	return JSON.parse_string(FileAccess.get_file_as_string(path))

func draft():
	return {"name":"서윤","gender":0,"age":25,"height":1,"body":1,"chest":1,"hair":0,"hair_color":0,"skin":0,"coat":0,"weapon":0,"discipline":0,"background":0,"traits":[]}

func trait_def(id):
	for t in traits:
		if t.id == id:
			return t
	return {}

func creation(d):
	var selected = []
	var bonus = 0
	var spent = 0
	var negatives = 0
	var positives = 0
	var violations = []
	for id in d.traits:
		if selected.has(id):
			continue
		var t = trait_def(id)
		if t.is_empty():
			violations.append("알 수 없는 특성")
			continue
		selected.append(id)
		bonus += int(t.points)
		spent += int(t.cost)
		if t.points > 0: negatives += 1
		else: positives += 1
	if negatives > int(balance.creation.max_negative): violations.append("불리 특성은 최대 3개")
	if positives > int(balance.creation.max_positive): violations.append("유리 특성은 최대 3개")
	bonus = mini(bonus,int(balance.creation.max_bonus))
	var budget = int(balance.creation.base_points)+bonus
	if spent > budget: violations.append("포인트가 부족해요")
	if d.name.strip_edges().is_empty() or d.name.length()>20: violations.append("이름은 1~20자")
	if d.age<18 or d.age>100: violations.append("성인 나이 18~100세")
	if selected.has("tree") and d.discipline!=1: violations.append("세계수 계승은 마법 계열에서 시작")
	if selected.has("demon") and d.discipline!=0: violations.append("천마 계승은 무공 계열에서 시작")
	var hp = 100.0
	if selected.has("steady"): hp += 20
	if selected.has("vital"): hp += 15
	if selected.has("fracture"): hp *= 0.75
	var dice = 0
	if selected.has("swift"): dice+=3
	if selected.has("slow"): dice-=2
	return {"budget":budget,"bonus":bonus,"spent":spent,"remaining":budget-spent,"negative":negatives,"positive":positives,"valid":violations.is_empty(),"violations":violations,"hp":floori(hp),"mp":50,"speed_min":maxi(1,1+dice),"speed_max":maxi(1,5+dice),"selected":selected}

func new_game(d, seed_value=27092050):
	var check = creation(d)
	if not check.valid:
		error = ", ".join(check.violations)
		return false
	s = {"save_version":3,"content_version":"0.3.0","campaign_id":str(Time.get_unix_time_from_system()),"revision":0,"time":0.0,"character":d.duplicate(true),"creation_ledger":{"budget":check.budget,"spent":check.spent,"granted":check.bonus,"origin":"CHARACTER_CREATION"},"hp":check.hp,"max_hp":check.hp,"mp":50,"max_mp":50,"morale":0,"stagger":0,"money":150,"potions":3,"level":1,"xp":0,"mastery":{},"deck":["edge","pierce","flurry","burst","resolve","heavy"],"position":[0.0,0.0,6.0],"world":{"chapter":0,"stage":0,"erosion":0.0,"collapsed":false,"outcome":"PENDING","gate_started":0.0,"gate_cleared":false,"gate_entered":false,"red":false,"red_reported":false,"evacuated":0,"medicine":false,"ledger":false,"baek_safe":false,"manifest":false,"support":false,"refuge_shop":false},"npc":{"baek":{"life":"ALIVE","location":"SHOP"},"taeo":{"life":"ALIVE","role":"ROOKIE"},"jian":{"trust":0},"hyejin":{"trust":0}},"evidence":[],"journal":[],"news":[],"flags":{},"rng":{"combat":int(seed_value),"gate":int(seed_value)+41},"battle":{},"exclusive_items":[],"training_rebuild_used":false}
	if check.selected.has("tree"): s.exclusive_items.append("세계수의 지팡이 UR")
	if check.selected.has("demon"): s.exclusive_items.append("천마신공 S")
	record("creation","등록 전의 하루가 시작됐다.")
	return true

func has_trait(id):
	return s.character.traits.has(id)

func cost(base):
	if base == 0: return 0
	var result = float(base)
	if has_trait("frugal"): result=ceil(result*0.9)
	if has_trait("leak"): result=ceil(result*1.25)
	return int(result)

func record(id, message):
	if s.flags.has(id): return false
	s.flags[id]=true
	s.revision+=1
	s.journal.append({"id":id,"at":s.time,"text":message})
	return true

func random01(stream):
	var n = (int(s.rng[stream])*48271)%2147483647
	if n<=0: n=1
	s.rng[stream]=n
	return float(n)/2147483647.0

func advance(minutes):
	if s.is_empty(): return
	var before = float(s.time)
	s.time += maxf(0.0,minutes)
	if s.world.chapter==1 and not s.world.gate_cleared and not s.world.collapsed:
		var due = float(s.world.gate_started)+float(balance.world.gate_grace_minutes)
		var elapsed = maxf(0.0,s.time-due)-maxf(0.0,before-due)
		s.world.erosion = minf(100.0,s.world.erosion+elapsed/60.0*float(balance.world.erosion_hourly))
		if before<due and s.time>=due:
			record("erosion_warning","발생 72시간 경과. 서림 침식이 시작됐다. 대피소와 게이트로 이동할 수 있다.")
		if s.time>=float(s.world.gate_started)+2160 and not s.flags.has("taeo_rescued"):
			s.npc.taeo.role="SUPPORT"
			record("taeo_injured","태오는 단독 구조 중 부상을 입었다. 통신 지원으로 역할을 바꾼다.")
		if s.world.erosion>=100:
			collapse()

func collapse():
	if s.world.collapsed: return
	s.world.collapsed=true
	s.world.outcome="EVACUATED_COLLAPSED" if s.world.evacuated>=90 else "HEAVY_LOSS"
	if not s.world.baek_safe:
		s.npc.baek.life="DEAD"
		s.npc.baek.location="LOST"
	else:
		s.npc.baek.location="REFUGE"
	s.npc.taeo.role="SUPPORT"
	s.news.append("서림 생활권 통행 폐쇄. 대피 인원 %d명. 피난민 지원 거점 운영 시작."%s.world.evacuated)
	record("collapse","서림이 붕괴했다. 대피한 인물은 남쪽 지원 거점으로 이동했다. 복구가 아닌 재정착이 시작된다.")

func story(action):
	error=""
	var w=s.world
	if s.flags.has(action): return false
	match action:
		"delivery":
			w.stage=maxi(w.stage,1)
			s.money+=20
			advance(10)
			record(action,"백도식의 장비를 전달했다. 작은 부탁을 기억해 두었다.")
		"register":
			if w.stage<1: return false
			w.stage=2
			record(action,"이지안에게 각성을 등록했다. 디바이스와 기본 연공법, 무기를 지급받았다.")
		"training_done":
			w.stage=3
			s.hp=s.max_hp; s.mp=s.max_mp; s.morale=0; s.stagger=0
			record(action,"교육 종료. 합·코인·정신력·흐트러짐을 확인했다. 교육 생략 시에도 지급품은 같다.")
		"first_clear":
			w.stage=4; w.chapter=1; w.gate_started=s.time
			w.gate_entered=false; w.red=false; w.red_reported=false
			s.money+=100
			s.hp=s.max_hp; s.mp=s.max_mp
			s.news.append("서림 동부에 신규 침략형 게이트 발생. 현장 확인과 주민 대피 지원이 필요합니다.")
			record(action,"첫 공략에서 귀환했다. 1장: 지도에서 사라지는 주소. 신규 게이트가 지금 발생했다.")
		"manifest":
			if w.chapter!=1: return false
			advance(48 if has_trait("insight") else 60)
			w.manifest=true; w.evacuated=mini(120,w.evacuated+30)
			s.evidence.append("현장 명단과 실제 거주 기록 대조: 임시 거주자 30명 누락 확인")
			record(action,"누락 명단을 대조하고 30명의 대피를 지원했다.")
		"buses":
			if w.chapter!=1: return false
			advance(180); w.evacuated=mini(120,w.evacuated+60)
			record(action,"버스와 운반 인력을 확보해 주민 60명을 대피시켰다.")
		"medicine":
			if s.money<60: error="구매·운송비 60 크레딧이 필요해요."; return false
			advance(30); s.money-=60; w.medicine=true; s.npc.hyejin.trust+=1
			record(action,"회복제를 구매해 오혜진의 의료 지원망에 전달했다. 비용 60, 소요 30분.")
		"medicine_paper":
			advance(240); w.medicine=true; s.npc.hyejin.trust+=1
			record(action,"담당자를 확인해 정식 인도 승인을 받았다. 의료 지원망 복구, 소요 4시간.")
		"ledger":
			advance(30); w.ledger=true
			record(action,"수리 장부를 촬영하고 안전한 보관처를 확보했다.")
		"baek_safe":
			if s.npc.baek.life!="ALIVE": return false
			advance(60 if w.ledger else 180); w.baek_safe=true
			s.npc.baek.location="REFUGE"
			w.evacuated=mini(120,w.evacuated+10)
			record(action,"백도식을 남쪽 대피 거점까지 동행했다. 생존과 새 위치가 기록됐다.")
		"taeo_rescued":
			advance(180); w.evacuated=mini(120,w.evacuated+20)
			if not s.flags.has("taeo_injured"): s.npc.taeo.role="LEADER"
			s.npc.jian.trust+=1
			record(action,"위치를 확인하고 이지안에게 지원을 요청했다. 태오와 고립 주민 구조를 마쳤다.")
		"gate_clear":
			w.gate_cleared=true
			if not w.collapsed:
				w.outcome="SECURED" if w.erosion<20 and w.medicine else "DAMAGED"
			s.money+=180
			s.news.append("서림 게이트 공략 완료. 결과: "+outcome_name()+". 대피·의료 지원의 후속 조치가 진행됩니다.")
			record(action,"게이트 위협을 제거했다. 이미 붕괴한 영역은 복원되지 않는다. 지역 결과: "+outcome_name())
		"reopen":
			if s.npc.baek.life!="ALIVE" or w.outcome=="PENDING": return false
			advance(120); w.refuge_shop=true
			record(action,"백도식의 수리대를 마련했다. 그는 첫 무기의 부품을 손봤다.")
		_:
			return false
	return true

func outcome_name():
	return {"PENDING":"진행 중","SECURED":"생활권 보존","DAMAGED":"손상 후 유지","EVACUATED_COLLAPSED":"대피 후 붕괴","HEAVY_LOSS":"대규모 손실"}.get(s.world.outcome,"진행 중")

func enter_gate():
	if not s.world.gate_entered:
		s.world.gate_entered=true
		s.world.red=random01("gate")<0.01
		save_slot("auto")
	return s.world.red

func skill(id):
	for definition in skills:
		if definition.id==id: return definition.duplicate(true)
	return {}

func start_battle(training=false):
	var hp=65 if training else (155 if s.world.chapter==1 else 88)
	if s.world.red and not training: hp=int(hp*1.5)
	s.battle={"training":training,"phase":"PLAN","turn":1,"enemy_hp":hp,"enemy_max":hp,"enemy_morale":0,"enemy_stagger":0,"enemy_broken":false,"player_broken":false,"enemy_skip":0,"player_skip":0,"enemy_intent":"attack","player_speed":1,"enemy_speed":1,"plans":[],"events":[],"won":false,"target":"clash"}
	begin_turn()

func begin_turn():
	var b=s.battle
	b.phase="PLAN"; b.plans=[]; b.events=[]
	var stats=creation(s.character)
	b.player_speed=stats.speed_min+int(random01("combat")*(stats.speed_max-stats.speed_min+1))
	b.enemy_speed=1+int(random01("combat")*5)
	b.enemy_intent="heavy" if int(b.turn)%3==0 else "attack"
	if b.training and b.turn==1: b.enemy_intent="observe"
	b.enemy_broken=b.enemy_skip>0
	b.player_broken=b.player_skip>0
	if b.enemy_broken: b.enemy_skip-=1
	if b.player_broken: b.player_skip-=1

func plan_action(id,target="clash"):
	if s.battle.is_empty() or s.battle.phase!="PLAN": return false
	var required=0
	if id not in ["basic","guard","focus","potion","retreat"]:
		if not s.deck.has(id): return false
		var definition=skill(id)
		if definition.is_empty(): return false
		required=cost(definition.cost)
	if required>s.mp: error="MP 부족 · 예약 비용 %d"%required; return false
	if id=="potion" and s.potions<=0: error="회복제가 없어요."; return false
	s.battle.plans=[{"skill":id,"cost":required,"target":target}]
	return true

func heads(morale):
	return random01("combat")<clampf(float(balance.combat.coin_base_chance)+float(morale)*float(balance.combat.morale_coin_coefficient),0.05,0.95)

func change_morale(player_side,amount):
	if player_side: s.morale=clampi(int(s.morale)+amount,-45,45)
	else: s.battle.enemy_morale=clampi(int(s.battle.enemy_morale)+amount,-45,45)

func hurt(player_side,amount,stagger_amount,events):
	var b=s.battle
	if player_side:
		if b.player_broken: amount=ceili(amount*float(balance.combat.stagger_vulnerability))
		if has_trait("echo"): amount=ceili(amount*1.20)
		s.hp=maxi(0,s.hp-amount); s.stagger+=stagger_amount
		if s.stagger>=float(balance.combat.stagger_threshold):
			s.stagger=0; b.player_skip=1
			events.append({"type":"stagger","player":true})
	else:
		if b.enemy_broken: amount=ceili(amount*float(balance.combat.stagger_vulnerability))
		b.enemy_hp=maxi(0,b.enemy_hp-amount); b.enemy_stagger+=stagger_amount
		if b.enemy_stagger>=float(balance.combat.stagger_threshold):
			b.enemy_stagger=0; b.enemy_skip=1
			events.append({"type":"stagger","player":false})

func resolve():
	var b=s.battle
	if b.is_empty() or b.phase!="PLAN" or b.plans.is_empty(): return []
	var p=b.plans[0]
	var id=p.skill
	var events=[]
	if p.cost>s.mp: return []
	b.phase="PLAYBACK"
	if id=="retreat":
		b.phase="ESCAPED"
		return [{"type":"escape"}]
	var skill_data=skill(id)
	if skill_data.is_empty(): skill_data={"id":id,"name":"기본 공격","base":5,"coin":3,"coins":1,"damage":7,"stagger":7,"motion":"slash","color":"b6eced"}
	var guarded=false
	var enemy_can_attack=b.enemy_intent!="observe" and not b.enemy_broken
	var player_can_attack=not b.player_broken
	if not player_can_attack:
		events.append({"type":"skip","player":true})
	else:
		s.mp-=p.cost
		if id=="guard":
			guarded=true
			s.stagger=maxi(0,s.stagger-10)
			events.append({"type":"guard","player":true})
		elif id=="focus":
			var amount=12
			if has_trait("tree") and s.character.discipline==1: amount*=4
			if has_trait("imperfect"): amount=floori(amount*0.65)
			s.mp=mini(s.max_mp,s.mp+amount); change_morale(true,5)
			events.append({"type":"recover","text":"MP +%d · 정신력 +5"%amount})
		elif id=="potion":
			s.potions-=1
			var amount=30 if not has_trait("slowheal") else 21
			s.hp=mini(s.max_hp,s.hp+amount)
			events.append({"type":"recover","text":"HP +%d"%amount})
		elif id=="resolve":
			change_morale(true,15); s.stagger=maxi(0,s.stagger-14)
			events.append({"type":"recover","text":"정신력 +15 · 흐트러짐 -14"})
		else:
			var coins=int(skill_data.coins)
			var enemy_coins=2 if b.enemy_intent=="heavy" else 1
			if p.target=="clash" and enemy_can_attack:
				var rounds=0
				while coins>0 and enemy_coins>0 and rounds<12:
					rounds+=1
					var power=int(skill_data.base)
					for c in range(coins):
						if heads(s.morale): power+=int(skill_data.coin)
					var enemy_power=6 if b.enemy_intent=="heavy" else 4
					for c in range(enemy_coins):
						if heads(b.enemy_morale): enemy_power+=3
					events.append({"type":"clash","a":power,"b":enemy_power})
					if power>enemy_power: enemy_coins-=1
					elif power<enemy_power: coins-=1
					elif rounds>=int(balance.combat.clash_tie_limit):
						coins-=1; enemy_coins-=1
				if coins>0:
					enemy_can_attack=false; change_morale(true,5); change_morale(false,-5)
				else:
					change_morale(true,-5); change_morale(false,5)
			for c in range(coins):
				var is_head=heads(s.morale)
				var damage=int(skill_data.damage)+(int(skill_data.coin) if is_head else 0)
				var mult=1.0
				if has_trait("steady"): mult+=0.2
				if has_trait("tree") and s.character.discipline==1: mult+=3.0
				if has_trait("demon") and s.character.discipline==0: mult+=2.0
				damage=floori(damage*mult)
				var resistance=0.75 if skill_data.get("type","")=="참격" and not b.training else 1.0
				damage=maxi(1,floori(damage*resistance))
				events.append({"type":"hit","player":false,"damage":damage,"head":is_head,"motion":skill_data.motion,"color":skill_data.color,"coin":c+1})
				hurt(false,damage,int(skill_data.stagger),events)
				if b.enemy_hp<=0: break
			if not b.training:
				var gain=1.0
				if has_trait("hard"): gain*=0.7
				if has_trait("tree") and s.character.discipline==1: gain*=3.0
				if has_trait("demon") and s.character.discipline==0: gain*=6.0
				s.mastery[id]=float(s.mastery.get(id,0.0))+gain
				if s.character.discipline==3 and not skill(id).is_empty(): s.max_mp+=0.3
	if enemy_can_attack and b.enemy_hp>0:
		var dmg=18 if b.enemy_intent=="heavy" else 11
		if guarded: dmg=maxi(1,dmg-12)
		events.append({"type":"hit","player":true,"damage":dmg,"head":true,"motion":"heavy","color":"ff776f","coin":1})
		hurt(true,dmg,4 if guarded else 14,events)
	if b.enemy_broken: events.append({"type":"skip","player":false})
	if b.enemy_hp<=0:
		b.won=true; events.append({"type":"victory"})
	elif s.hp<=0:
		events.append({"type":"defeat"})
	b.events=events.duplicate(true)
	return events

func finish_playback():
	if s.battle.is_empty(): return ""
	var b=s.battle
	if b.won:
		var training=b.training
		s.battle={}
		if training: story("training_done")
		elif s.world.chapter==0: story("first_clear")
		else: story("gate_clear")
		s.xp+=20 if not training else 0
		return "victory"
	if s.hp<=0:
		var training=b.training
		s.battle={}
		s.hp=s.max_hp; s.mp=s.max_mp; s.stagger=0
		if training: story("training_done")
		else:
			advance(360); s.money=maxi(0,s.money-30)
			record("battle_failure_%d"%int(s.time),"감독 인력이 철수를 지원했다. 치료에 6시간과 30 크레딧을 사용했다.")
		return "defeat"
	if not b.training: advance(float(balance.combat.turn_minutes))
	b.turn+=1
	begin_turn()
	return "next"

func rest():
	advance(float(balance.world.rest_minutes))
	s.hp=s.max_hp; s.mp=s.max_mp; s.morale=0; s.stagger=0

func save_slot(slot):
	if s.is_empty(): return false
	if not s.battle.is_empty() and s.battle.phase=="PLAYBACK": error="연출이 끝난 계획 단계에서 저장해요."; return false
	var payload=JSON.stringify(s)
	var path=save_dir+"bmh_"+slot+".json"
	var temp=path+".new"
	var f=FileAccess.open(temp,FileAccess.WRITE)
	if f==null: error="저장 파일을 쓸 수 없어요."; return false
	f.store_string(JSON.stringify({"version":3,"digest":payload.sha256_text(),"payload":payload}))
	f.close()
	if not valid_file(temp): error="저장 검증 실패"; return false
	if FileAccess.file_exists(path):
		DirAccess.copy_absolute(path,path+".bak")
	var result=DirAccess.rename_absolute(temp,path)
	return result==OK

func valid_file(path):
	var wrapper=read_json(path)
	if not wrapper is Dictionary or not wrapper.has_all(["version","digest","payload"]): return false
	if wrapper.version!=3 or not wrapper.payload is String: return false
	if wrapper.payload.sha256_text()!=wrapper.digest: return false
	var state=JSON.parse_string(wrapper.payload)
	return validate_state(state)

func validate_state(state):
	if not state is Dictionary: return false
	if not state.has_all(["save_version","character","time","world","npc","rng","battle","journal","flags","hp","max_hp","position","creation_ledger","deck"]): return false
	if state.save_version!=3 or not state.character is Dictionary: return false
	if not state.character.has_all(["name","age","gender","height","body","chest","hair","hair_color","skin","coat","weapon","discipline","background","traits"]): return false
	if not creation(state.character).valid: return false
	if state.time<0 or state.max_hp<1 or state.hp<0 or state.hp>state.max_hp: return false
	if not state.position is Array or state.position.size()!=3: return false
	if not state.world.has_all(["chapter","stage","collapsed","erosion","outcome","gate_cleared","gate_started","gate_entered","red","evacuated","medicine","ledger","baek_safe","manifest","refuge_shop"]): return false
	if state.world.erosion<0 or state.world.erosion>100: return false
	if not state.npc.has_all(["baek","taeo","jian","hyejin"]): return false
	if state.npc.baek.life not in ["ALIVE","DEAD"]: return false
	if not state.rng.has_all(["combat","gate"]): return false
	if not state.battle.is_empty():
		if not state.battle.has_all(["phase","turn","plans","enemy_hp","enemy_max","player_speed","enemy_speed"]): return false
		if state.battle.phase!="PLAN": return false
	return true

func load_slot(slot):
	var path=save_dir+"bmh_"+slot+".json"
	if not valid_file(path):
		if valid_file(path+".bak"): path+=".bak"
		else: error="정상 저장본을 찾지 못했어요."; return false
	var restored=JSON.parse_string(read_json(path).payload)
	if not s.is_empty(): save_slot("before_load")
	s=restored
	return true

func has_save(slot):
	return valid_file(save_dir+"bmh_"+slot+".json")
