extends Node
var players=[]
var music
var enabled=true
func _ready():
	for i in range(4):
		var p=AudioStreamPlayer.new(); add_child(p); players.append(p)
	music=AudioStreamPlayer.new(); music.stream=load("res://assets/night.wav"); music.volume_db=-20; add_child(music)
func start_music():
	if enabled and not music.playing: music.play()
func effect(which):
	if not enabled: return
	for p in players:
		if not p.playing:
			p.stream=load("res://assets/"+which+".wav"); p.play(); return
func set_enabled(value):
	enabled=value
	if value: start_music()
	else:
		music.stop()
		for p in players: p.stop()
