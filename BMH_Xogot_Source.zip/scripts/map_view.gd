extends Control
signal destination(id)
var world
var selected=""
var player_pos=Vector3.ZERO
var font
func _ready():
	font=preload("res://scripts/fonts.gd").korean()
	mouse_filter=Control.MOUSE_FILTER_STOP
func map_pos(p):
	return Vector2((p.x+45)/90.0*size.x,(p.z+46)/94.0*size.y)
func _draw():
	draw_rect(Rect2(Vector2.ZERO,size),Color("0b202b"))
	for x in range(1,9): draw_line(Vector2(x*size.x/9,0),Vector2(x*size.x/9,size.y),Color("193843"))
	for y in range(1,9): draw_line(Vector2(0,y*size.y/9),Vector2(size.x,y*size.y/9),Color("193843"))
	draw_line(map_pos(Vector3(-40,0,4)),map_pos(Vector3(40,0,4)),Color("56717a"),10)
	draw_line(map_pos(Vector3(0,0,-40)),map_pos(Vector3(0,0,42)),Color("56717a"),8)
	draw_line(map_pos(Vector3(-35,0,30)),map_pos(Vector3(38,0,30)),Color("56717a"),8)
	if world!=null:
		for id in world.points:
			var p=world.points[id]
			if not p.active: continue
			var point=map_pos(p.position)
			if id==selected: draw_line(map_pos(player_pos),point,Color("e7c781"),2)
			draw_circle(point,6,Color("e5c986") if id==selected else Color("70bfb6"))
			draw_string(font,point+Vector2(8,-5),p.caption.split(" · ")[0],HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color("cadcda"))
	var pp=map_pos(player_pos)
	draw_circle(pp,7,Color("ffffff")); draw_arc(pp,11,0,TAU,20,Color("80ede0"),2)
func _gui_input(event):
	if event is InputEventMouseButton and event.pressed:
		if world==null: return
		var nearest=""; var best=36.0
		for id in world.points:
			var p=world.points[id]
			if not p.active: continue
			var d=map_pos(p.position).distance_to(event.position)
			if d<best: nearest=id; best=d
		if not nearest.is_empty(): selected=nearest; destination.emit(nearest); queue_redraw()
