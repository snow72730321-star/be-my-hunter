extends Control
var from_point=Vector2.ZERO
var to_point=Vector2.ZERO
var line_color=Color("e2bd6e")
var shown=false
func _ready():mouse_filter=Control.MOUSE_FILTER_IGNORE
func _draw():
	if not shown:return
	var pts=PackedVector2Array()
	for i in range(41):
		var t=i/40.0;var p=from_point.lerp(to_point,t);p.y-=sin(t*PI)*100;pts.append(p)
	draw_polyline(pts,Color(line_color,.14),9,true);draw_polyline(pts,line_color,2,true)
	var tangent=(pts[-1]-pts[-3]).normalized();var normal=Vector2(-tangent.y,tangent.x)
	draw_colored_polygon(PackedVector2Array([to_point,to_point-tangent*13+normal*5,to_point-tangent*13-normal*5]),line_color)
