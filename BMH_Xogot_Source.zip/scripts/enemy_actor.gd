extends Node3D
var sprite
var clock=0.0
var pose=-1
func _ready():
	sprite=Sprite3D.new(); sprite.texture=load("res://assets/enemy_sentinel.png")
	sprite.hframes=4; sprite.vframes=2; sprite.pixel_size=.0067
	sprite.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	sprite.texture_filter=BaseMaterial3D.TEXTURE_FILTER_NEAREST
	sprite.alpha_cut=SpriteBase3D.ALPHA_CUT_DISCARD
	sprite.position.y=1.5; add_child(sprite)
	var sh=MeshInstance3D.new();var mesh=CylinderMesh.new();mesh.top_radius=.85;mesh.bottom_radius=.85;mesh.height=.01
	sh.mesh=mesh;var m=StandardMaterial3D.new();m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;m.albedo_color=Color(0,0,0,.35);m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	sh.material_override=m;sh.position.y=.02;add_child(sh)
func set_pose(value):
	pose=value
	if sprite!=null and value>=0:sprite.frame=value
func _process(delta):
	clock+=delta
	if sprite!=null and pose<0:sprite.frame=int(clock*1.5)%2
