extends RefCounted
static func korean():
	if ResourceLoader.exists("res://assets/BMH_Korean.otf"):
		return load("res://assets/BMH_Korean.otf")
	var font=SystemFont.new()
	font.font_names=PackedStringArray(["Apple SD Gothic Neo","Noto Sans CJK KR","Noto Sans","sans-serif"])
	return font
