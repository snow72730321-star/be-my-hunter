extends SceneTree
const State=preload("res://scripts/game_state.gd")
var checks=0
func check(condition,message):
	if not condition:
		push_error("FAIL: "+message); quit(1)
		return false
	checks+=1
	print("PASS: "+message)
	return true
func _initialize():
	var g=State.new(); var d=g.draft()
	check(g.creation(d).valid,"no drawbacks or positive traits required")
	d.traits=["demon","insight","fracture","leak","echo"]
	check(g.creation(d).valid and g.creation(d).budget==24,"24 point extreme build")
	d.traits.append("slow")
	check(not g.creation(d).valid,"four drawbacks rejected")
	d.traits=["tree"]; check(not g.creation(d).valid,"over budget and incompatible discipline rejected")
	d=g.draft(); d.traits=["steady","vital"]; var hp=g.creation(d).hp
	d.gender=1; d.body=2; d.chest=2; d.height=2
	check(g.creation(d).hp==hp,"appearance independent from combat")
	d=g.draft(); d.traits=["demon","insight","fracture","leak","echo"]
	g.new_game(d,42)
	check(g.s.max_hp==75 and g.cost(12)==15,"drawback order hp and mp")
	check(g.s.exclusive_items.has("천마신공 S"),"exclusive talent content granted")
	g.s.world.stage=2; g.start_battle(true)
	g.s.mp=10
	check(not g.plan_action("heavy"),"MP reservation cannot overspend")
	g.s.mp=50; g.plan_action("edge"); var reserved=g.s.mp
	check(reserved==50,"planning reserves but does not spend")
	var original=JSON.stringify(g.s)
	g.save_dir="user://qa_rules_"
	check(g.save_slot("battle"),"battle plan persisted")
	g.resolve(); var outcome=JSON.stringify(g.s)
	check(not g.save_slot("unsafe"),"playback save rejected")
	g.s.battle={}; check(g.load_slot("battle"),"full battle snapshot restored")
	check(JSON.stringify(g.s)==original,"load does not reroll speed or change inventory")
	g.resolve(); check(JSON.stringify(g.s)==outcome,"same saved inputs same combat result")
	var a=State.new(); var b=State.new(); a.new_game(a.draft(),91); b.new_game(b.draft(),91)
	a.story("first_clear"); b.story("first_clear")
	a.advance(5000)
	for i in range(100): b.advance(50)
	check(abs(a.s.world.erosion-b.s.world.erosion)<.000001,"time partition invariance")
	var red=a.enter_gate(); var rng=a.s.rng.gate
	check(a.enter_gate()==red and a.s.rng.gate==rng,"entry mutation exactly once")
	var c=State.new(); c.new_game(c.draft(),11); c.story("first_clear"); c.story("manifest"); c.story("buses"); c.story("ledger"); c.story("baek_safe"); c.advance(9000)
	check(c.s.world.outcome=="EVACUATED_COLLAPSED" and c.s.npc.baek.life=="ALIVE" and c.s.npc.baek.location=="REFUGE","collapse preserves actually evacuated NPC")
	var journal_size=c.s.journal.size(); c.story("ledger")
	check(c.s.journal.size()==journal_size,"story rewards idempotent")
	var normal=State.new(); normal.new_game(normal.draft()); normal.s.battle={"enemy_hp":60,"enemy_stagger":0,"enemy_broken":false,"player_broken":false,"enemy_skip":0,"player_skip":0}
	var ev=[]; normal.hurt(false,10,43,ev)
	check(normal.s.battle.enemy_skip==1 and normal.s.battle.enemy_stagger==0,"stagger schedules one future skipped turn")
	check(normal.s.morale==0 and normal.s.mp==50,"morale separate from MP")
	var broken=c.s.duplicate(true); broken.hp=-99
	check(not c.validate_state(broken),"invalid save rejected atomically")
	print("BMH_RULES_OK ",checks)
	quit(0)
