extends SceneTree
const State=preload("res://scripts/game_state.gd")
var checks=0
var failed=false
func check(condition,message):
	if not condition:
		failed=true; push_error("FAIL: "+message)
		return false
	checks+=1
	print("PASS: "+message)
	return true
func _initialize():
	var g=State.new(); var d=g.draft()
	check(g.creation(d).valid,"no drawbacks or positive traits required")
	d.traits=["demon","insight","fracture","leak","echo"]
	check(g.creation(d).valid and g.creation(d).budget==24,"24 point extreme build")
	d.traits.append("slow")
	check(not g.creation(d).valid,"four drawbacks rejected")
	d.traits=["tree"]; check(not g.creation(d).valid,"over budget and incompatible discipline rejected")
	d=g.draft(); d.traits=["steady","vital"]; var hp=g.creation(d).hp
	d.gender=1; d.body=2; d.chest=2; d.height=2
	check(g.creation(d).hp==hp,"appearance independent from combat")
	d=g.draft(); d.traits=["demon","insight","fracture","leak","echo"]
	g.new_game(d,42)
	check(g.s.max_hp==75 and g.cost(12)==15,"drawback order hp and mp")
	check(g.s.exclusive_items.has("천마신공 S"),"exclusive talent content granted")
	g.equip_weapon(0)
	g.s.world.stage=2; g.start_battle(true)
	g.s.mp=10
	check(not g.plan_action("heavy"),"MP reservation cannot overspend")
	g.s.mp=50; check(g.plan_action("edge"),"equipped sword accepts sword skill"); var reserved=g.s.mp
	check(reserved==50,"planning reserves but does not spend")
	var original=JSON.stringify(g.s)
	g.save_dir="user://qa_rules_"
	check(g.save_slot("battle"),"battle plan persisted")
	g.resolve(); var outcome=JSON.stringify(g.s)
	check(not g.save_slot("unsafe"),"playback save rejected")
	g.s.battle={}; check(g.load_slot("battle"),"full battle snapshot restored")
	check(preload("res://tests/compare.gd").same(g.s,JSON.parse_string(original)),"load does not reroll speed or change inventory")
	g.resolve(); check(preload("res://tests/compare.gd").same(g.s,JSON.parse_string(outcome)),"same saved inputs same combat result")
	var a=State.new(); var b=State.new(); a.new_game(a.draft(),91); b.new_game(b.draft(),91)
	a.story("first_clear"); b.story("first_clear")
	a.advance(5000)
	for i in range(100): b.advance(50)
	check(abs(a.s.world.erosion-b.s.world.erosion)<.000001,"time partition invariance")
	check(a.s.journal==b.s.journal,"scheduled story event timestamps independent of advance size")
	var red=a.enter_gate(); var rng=a.s.rng.gate
	check(a.enter_gate()==red and a.s.rng.gate==rng,"entry mutation exactly once")
	var c=State.new(); c.new_game(c.draft(),11); c.story("first_clear"); c.story("manifest"); c.story("buses"); c.story("ledger"); c.story("baek_safe"); c.advance(9000)
	check(c.s.world.outcome=="EVACUATED_COLLAPSED" and c.s.npc.baek.life=="ALIVE" and c.s.npc.baek.location=="REFUGE","collapse preserves actually evacuated NPC")
	var journal_size=c.s.journal.size(); c.story("ledger")
	check(c.s.journal.size()==journal_size,"story rewards idempotent")
	var normal=State.new(); normal.new_game(normal.draft()); normal.s.battle={"enemy_hp":60,"enemy_stagger":0,"enemy_broken":false,"player_broken":false,"enemy_skip":0,"player_skip":0}
	var ev=[]; normal.hurt(false,10,43,ev)
	check(normal.s.battle.enemy_skip==1 and normal.s.battle.enemy_stagger==0,"stagger schedules one future skipped turn")
	check(normal.s.morale==0 and normal.s.mp==50,"morale separate from MP")
	var broken=c.s.duplicate(true); broken.hp=-99
	check(not c.validate_state(broken),"invalid save rejected atomically")
	var free=State.new();free.new_game(free.draft(),71)
	var ledger=free.s.creation_ledger.duplicate(true);var health=free.s.hp
	for kind in range(6):check(free.equip_weapon(kind) and free.s.hp==health and free.s.creation_ledger==ledger,"free equipment family %d preserves character"%kind)
	free.equip_weapon(4);check(not free.skill_compatible("edge") and free.skill_compatible("flurry"),"weapon compatibility follows current equipment")
	free.s.mp=13;free.set_discipline(1);free.s.mp=7;free.set_discipline(0)
	check(free.s.mp==13,"discipline change restores own MP pool without refill")
	free.set_discipline(1);check(free.s.mp==7,"returning discipline retains spent MP")
	free.s.world.red=true
	check(not free.gate_report().actual_known and not "변이" in free.gate_report().status,"gate UI does not expose unknown mutation")
	free.s.world.red=false;check(free.request_gate_support(),"device support request recorded")
	var count=free.s.journal.size();free.request_gate_support();check(free.s.journal.size()==count,"support request cannot duplicate rewards")
	free.start_battle(true);check(not free.equip_weapon(0) and not free.set_discipline(2),"equipment change cannot invalidate active battle")
	free.s.battle.enemy_intent="attack";free.s.battle.enemy_speed=5;free.s.battle.player_speed=1;free.plan_action("basic","body")
	var ordered=free.resolve();check(ordered[0].type=="hit" and ordered[0].player,"faster unopposed enemy acts before player")
	var inherited=State.new();var inherited_draft=inherited.draft();inherited_draft.discipline=1;inherited_draft.traits=["tree","fracture","leak"]
	inherited.new_game(inherited_draft,66);inherited.set_discipline(0)
	check(inherited.validate_state(inherited.s),"talent birth prerequisites do not lock later build or saves")
	inherited.save_dir="user://qa_equipment_";inherited.save_slot("roundtrip");inherited.load_slot("roundtrip")
	check(inherited.equip_weapon(3) and inherited.skill_compatible("pierce"),"equipment IDs remain compatible after JSON save/load")
	if not failed: print("BMH_RULES_OK ",checks)
	quit(1 if failed else 0)
