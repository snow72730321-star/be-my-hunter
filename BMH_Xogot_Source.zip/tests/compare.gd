extends RefCounted
# JSON has one number type. Compare every stored value, without treating int/float spelling as a game event.
static func same(a,b):
	if (a is int or a is float) and (b is int or b is float): return a==b
	if a is Dictionary and b is Dictionary:
		if a.size()!=b.size(): return false
		for key in a:
			if not b.has(key) or not same(a[key],b[key]): return false
		return true
	if a is Array and b is Array:
		if a.size()!=b.size(): return false
		for i in range(a.size()):
			if not same(a[i],b[i]): return false
		return true
	return a==b
