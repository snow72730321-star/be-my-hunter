# 0.2 → 0.3 engine boundary

0.2 is the earlier GDevelop/DOM presentation. 0.3 is a new native Godot scene graph with a continuous 3D district, billboard pixel actors and native Controls. It is not a wrapper of the previous HTML game.

Retained concepts: BMH world, named NPCs, Seorim, point budget and seven drawbacks, deterministic entry mutation, clash/coin actions, snapshot saving and chapter-one consequences.
New runtime: GDScript State, native 3D World, animated Actor, native menu/creation/HUD/Device/Combat Controls, independent morale and stagger, ShaderMaterial palette/body profiles.

The legacy future-story graph and master document in docs are references only. Their old implementation labels refer to the GDevelop build and do not establish native Godot completion. New implementation status is documented in README and VALIDATION.

Save schema 3 has a new namespace and native file layer. There is no implicit migration of GDevelop localStorage saves. This avoids mixing money/NPC/world states across incompatible formats. Existing web saves remain at the old game's origin and path.

Rendering: desktop and Web use Compatibility. iOS/mobile select Mobile rendering; iPhone Xogot hardware validation is still required. No GDExtension, C# or separate game service.
