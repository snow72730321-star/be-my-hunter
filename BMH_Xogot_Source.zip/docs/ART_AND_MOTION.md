# BMH 0.4 art and motion

Built-in image generation produced new BMH original assets. Source PNG files are retained, with no destructive resampling. All character frames are quantized at shader sampling time; background and weapon textures remain full resolution.

| File | Content | Use |
|---|---|---|
| hunter_field_f / hunter_field_m.png | Adult normal-proportion female/male, 4 × 4 pose atlases | Field and creation |
| hunter_sd_f / hunter_sd_m.png | Separate SD female/male, 4 × 4 pose atlases | Battle and SD preview |
| enemy_sentinel.png | Original armored guardian, 4 × 2 atlas | Battle enemy |
| arena_cinematic.png | Nonpixel wet street, layered architecture, distant gate | Perspective 3D arena backdrop |
| city_facades.png | Six high-resolution shop/association/residential facades | 3D field building fronts and sides |
| weapons_detail.png | Sword, dao, katana, spear, gauntlet, focus; 3 × 2 atlas | Equipment, skill cards and hand attachment |
| seorim_dusk.png | Previous original blue-hour Korean city | Title backdrop |

Production prompts: adult 25-year-old original hunter; silver/lavender hair, emerald eyes, ivory shirt, navy/gold practical coat; female wears shorts and opaque tights, male trousers. Separate normal field and three-head SD versions. Transparent equally spaced grids, consistent feet baseline, full body padding, no weapons painted into character hands. Pose rows: idle/walk; launch/run/brake; windup/swing/follow/recover; guard/hit/stagger/cast.
Arena: wide nonpixel stylized 3D modern-fantasy city, cream architecture, warm lamps, wet reflective street, cyan far gate, clear combat floor. Facades: six detailed front elevations, repair shop, association, pharmacy, townhouse, cafe, warehouse. Weapons: six separate upright polished metal/gold/teal weapon illustrations on transparent 512-pixel cells. Enemy: original SD dark knight, fractured gold armor, cyan fissures, left facing, eight idle/attack/hit/guard/stagger/fallen poses.

Pose IDs 0–15 and hand attachments are in scripts/hunter_actor.gd. Body/height/chest/hair volume and palette changes are visual only. Facial proportions and hairstyles are atlas presets, not an unlimited facial sculpting system. Common NPC art still reuses the field hunter presets.

Motion data: data/motion_profiles.json defines six family rhythms; data/skill_motions.json defines ten named-skill overrides plus common magic. Position, grip anchor and camera-oriented weapon rotation are independent of body frame. Sword swings, dao has heavier anticipation, katana draw uses afterimages and narrow cutting VFX, spear thrust and sweep differ, fists use short impact arcs, focus has projectile travel or expanding field impact. One impact presentation corresponds to one actual hit event. Visual RNG does not touch the campaign RNG.

The nonpixel VFX use procedural additive flares, rings, tapered arc meshes and sparks. They are not borrowed effect sheets. Original synthesized WAV audio remains provisional. Buildings use textured 3D blocks; the arena uses a 3D backdrop plane with ground and foreground geometry, not a fully traversable detailed combat city.

Reference: https://limbuscompany.com/ and https://store.steampowered.com/app/1973530/Limbus_Company/ . Reference elements are speed/action presentation, clash/coin rhythm, anticipation, impact and return. BMH retains its one-protagonist, directly selected skill deck; this build does not reproduce the full Limbus party, identity, EGO or resonance systems. No original Limbus art, sound or UI files are included.
